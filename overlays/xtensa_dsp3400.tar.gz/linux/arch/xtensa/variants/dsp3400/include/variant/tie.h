/* 
 * tie.h -- compile-time HAL definitions dependent on CORE & TIE configuration
 *
 *  NOTE:  This header file is not meant to be included directly.
 */

/* This header file describes this specific Xtensa processor's TIE extensions
   that extend basic Xtensa core functionality.  It is customized to this
   Xtensa processor configuration.

   Copyright (c) 1999-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */

#ifndef _XTENSA_CORE_TIE_H
#define _XTENSA_CORE_TIE_H

#define XCHAL_CP_NUM			2	/* number of coprocessors */
#define XCHAL_CP_MAX			3	/* max CP ID + 1 (0 if none) */
#define XCHAL_CP_MASK			0x05	/* bitmask of all CPs by ID */
#define XCHAL_CP_PORT_MASK		0x00	/* bitmask of only port CPs */

/*  Basic parameters of each coprocessor:  */
#define XCHAL_CP0_NAME			"FPU"
#define XCHAL_CP0_IDENT			FPU
#define XCHAL_CP0_SA_SIZE		72	/* size of state save area */
#define XCHAL_CP0_SA_ALIGN		4	/* min alignment of save area */
#define XCHAL_CP_ID_FPU			0	/* coprocessor ID (0..7) */
#define XCHAL_CP2_NAME			"dsp3400copro_state"
#define XCHAL_CP2_IDENT			dsp3400copro_state
#define XCHAL_CP2_SA_SIZE		1552	/* size of state save area */
#define XCHAL_CP2_SA_ALIGN		16	/* min alignment of save area */
#define XCHAL_CP_ID_DSP3400COPRO_STATE	2	/* coprocessor ID (0..7) */

/*  Filler info for unassigned coprocessors, to simplify arrays etc:  */
#define XCHAL_CP1_SA_SIZE		0
#define XCHAL_CP1_SA_ALIGN		1
#define XCHAL_CP3_SA_SIZE		0
#define XCHAL_CP3_SA_ALIGN		1
#define XCHAL_CP4_SA_SIZE		0
#define XCHAL_CP4_SA_ALIGN		1
#define XCHAL_CP5_SA_SIZE		0
#define XCHAL_CP5_SA_ALIGN		1
#define XCHAL_CP6_SA_SIZE		0
#define XCHAL_CP6_SA_ALIGN		1
#define XCHAL_CP7_SA_SIZE		0
#define XCHAL_CP7_SA_ALIGN		1

/*  Save area for non-coprocessor optional and custom (TIE) state:  */
#define XCHAL_NCP_SA_SIZE		12
#define XCHAL_NCP_SA_ALIGN		4

/*  Total save area for optional and custom state (NCP + CPn):  */
#define XCHAL_TOTAL_SA_SIZE		1648	/* with 16-byte align padding */
#define XCHAL_TOTAL_SA_ALIGN		16	/* actual minimum alignment */

/*
 * Detailed contents of save areas.
 * NOTE:  caller must define the XCHAL_SA_REG macro (not defined here)
 * before expanding the XCHAL_xxx_SA_LIST() macros.
 *
 * XCHAL_SA_REG(s,ccused,abikind,kind,opt,name,galign,align,asize,
 *		dbnum,base,regnum,bitsz,gapsz,reset,x...)
 *
 *	s = passed from XCHAL_*_LIST(s), eg. to select how to expand
 *	ccused = set if used by compiler without special options or code
 *	abikind = 0 (caller-saved), 1 (callee-saved), or 2 (thread-global)
 *	kind = 0 (special reg), 1 (TIE user reg), or 2 (TIE regfile reg)
 *	opt = 0 (custom TIE extension or coprocessor), or 1 (optional reg)
 *	name = lowercase reg name (no quotes)
 *	galign = group byte alignment (power of 2) (galign >= align)
 *	align = register byte alignment (power of 2)
 *	asize = allocated size in bytes (asize*8 == bitsz + gapsz + padsz)
 *	  (not including any pad bytes required to galign this or next reg)
 *	dbnum = unique target number f/debug (see <xtensa-libdb-macros.h>)
 *	base = reg shortname w/o index (or sr=special, ur=TIE user reg)
 *	regnum = reg index in regfile, or special/TIE-user reg number
 *	bitsz = number of significant bits (regfile width, or ur/sr mask bits)
 *	gapsz = intervening bits, if bitsz bits not stored contiguously
 *	(padsz = pad bits at end [TIE regfile] or at msbits [ur,sr] of asize)
 *	reset = register reset value (or 0 if undefined at reset)
 *	x = reserved for future use (0 until then)
 *
 *  To filter out certain registers, e.g. to expand only the non-global
 *  registers used by the compiler, you can do something like this:
 *
 *  #define XCHAL_SA_REG(s,ccused,p...)	SELCC##ccused(p)
 *  #define SELCC0(p...)
 *  #define SELCC1(abikind,p...)	SELAK##abikind(p)
 *  #define SELAK0(p...)		REG(p)
 *  #define SELAK1(p...)		REG(p)
 *  #define SELAK2(p...)
 *  #define REG(kind,tie,name,galn,aln,asz,csz,dbnum,base,rnum,bsz,rst,x...) \
 *		...what you want to expand...
 */

#define XCHAL_NCP_SA_NUM	3
#define XCHAL_NCP_SA_LIST(s)	\
 XCHAL_SA_REG(s,0,0,0,1,             br, 4, 4, 4,0x0204,  sr,4  , 16,0,0,0) \
 XCHAL_SA_REG(s,0,0,0,1,      scompare1, 4, 4, 4,0x020C,  sr,12 , 32,0,0,0) \
 XCHAL_SA_REG(s,1,2,1,1,      threadptr, 4, 4, 4,0x03E7,  ur,231, 32,0,0,0)

#define XCHAL_CP0_SA_NUM	18
#define XCHAL_CP0_SA_LIST(s)	\
 XCHAL_SA_REG(s,0,0,1,0,            fcr, 4, 4, 4,0x03E8,  ur,232, 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,            fsr, 4, 4, 4,0x03E9,  ur,233, 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f0, 4, 4, 4,0x0030,   f,0  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f1, 4, 4, 4,0x0031,   f,1  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f2, 4, 4, 4,0x0032,   f,2  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f3, 4, 4, 4,0x0033,   f,3  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f4, 4, 4, 4,0x0034,   f,4  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f5, 4, 4, 4,0x0035,   f,5  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f6, 4, 4, 4,0x0036,   f,6  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f7, 4, 4, 4,0x0037,   f,7  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f8, 4, 4, 4,0x0038,   f,8  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,             f9, 4, 4, 4,0x0039,   f,9  , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            f10, 4, 4, 4,0x003A,   f,10 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            f11, 4, 4, 4,0x003B,   f,11 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            f12, 4, 4, 4,0x003C,   f,12 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            f13, 4, 4, 4,0x003D,   f,13 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            f14, 4, 4, 4,0x003E,   f,14 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            f15, 4, 4, 4,0x003F,   f,15 , 32,0,0,0)

#define XCHAL_CP1_SA_NUM	0
#define XCHAL_CP1_SA_LIST(s)	/* empty */

#define XCHAL_CP2_SA_NUM	107
#define XCHAL_CP2_SA_LIST(s)	\
 XCHAL_SA_REG(s,0,0,1,0,            sov,16, 4, 4,0x0301,  ur,1  ,  4,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,       sat_mode, 4, 4, 4,0x0302,  ur,2  ,  1,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,           sar0, 4, 4, 4,0x0303,  ur,3  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,           sar1, 4, 4, 4,0x0304,  ur,4  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,           sar2, 4, 4, 4,0x0305,  ur,5  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,           sar3, 4, 4, 4,0x0306,  ur,6  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,          hsar0, 4, 4, 4,0x0307,  ur,7  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,          hsar1, 4, 4, 4,0x0308,  ur,8  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,          hsar2, 4, 4, 4,0x0309,  ur,9  ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,          hsar3, 4, 4, 4,0x030A,  ur,10 ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      max_reg_0, 4, 4, 4,0x030B,  ur,11 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      max_reg_1, 4, 4, 4,0x030C,  ur,12 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      max_reg_2, 4, 4, 4,0x030D,  ur,13 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      max_reg_3, 4, 4, 4,0x030E,  ur,14 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  arg_max_reg_0, 4, 4, 4,0x030F,  ur,15 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  arg_max_reg_1, 4, 4, 4,0x0310,  ur,16 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  arg_max_reg_2, 4, 4, 4,0x0311,  ur,17 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  arg_max_reg_3, 4, 4, 4,0x0312,  ur,18 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  nco_counter_0, 4, 4, 4,0x0313,  ur,19 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  nco_counter_1, 4, 4, 4,0x0314,  ur,20 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  nco_counter_2, 4, 4, 4,0x0315,  ur,21 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  nco_counter_3, 4, 4, 4,0x0316,  ur,22 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,   interp_ext_n, 4, 4, 4,0x0317,  ur,23 ,  4,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,   interp_ext_l, 4, 4, 4,0x0318,  ur,24 ,  4,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_0, 4, 4, 4,0x0319,  ur,25 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_1, 4, 4, 4,0x031A,  ur,26 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_2, 4, 4, 4,0x031B,  ur,27 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_3, 4, 4, 4,0x031C,  ur,28 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_4, 4, 4, 4,0x031D,  ur,29 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_5, 4, 4, 4,0x031E,  ur,30 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_6, 4, 4, 4,0x031F,  ur,31 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_7, 4, 4, 4,0x0320,  ur,32 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_8, 4, 4, 4,0x0321,  ur,33 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      llr_buf_9, 4, 4, 4,0x0322,  ur,34 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_10, 4, 4, 4,0x0323,  ur,35 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_11, 4, 4, 4,0x0324,  ur,36 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_12, 4, 4, 4,0x0325,  ur,37 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_13, 4, 4, 4,0x0326,  ur,38 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_14, 4, 4, 4,0x0327,  ur,39 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_15, 4, 4, 4,0x0328,  ur,40 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_16, 4, 4, 4,0x0329,  ur,41 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_17, 4, 4, 4,0x032A,  ur,42 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_18, 4, 4, 4,0x032B,  ur,43 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_19, 4, 4, 4,0x032C,  ur,44 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_20, 4, 4, 4,0x032D,  ur,45 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_21, 4, 4, 4,0x032E,  ur,46 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_22, 4, 4, 4,0x032F,  ur,47 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     llr_buf_23, 4, 4, 4,0x0330,  ur,48 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_0, 4, 4, 4,0x0331,  ur,49 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_1, 4, 4, 4,0x0332,  ur,50 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_2, 4, 4, 4,0x0333,  ur,51 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_3, 4, 4, 4,0x0334,  ur,52 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_4, 4, 4, 4,0x0335,  ur,53 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_5, 4, 4, 4,0x0336,  ur,54 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_6, 4, 4, 4,0x0337,  ur,55 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     smod_buf_7, 4, 4, 4,0x0338,  ur,56 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,     weight_reg, 4, 4, 4,0x0339,  ur,57 ,  8,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,      scale_reg, 4, 4, 4,0x033A,  ur,58 ,  5,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,        llr_pos, 4, 4, 4,0x033B,  ur,59 ,  6,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,       smod_pos, 4, 4, 4,0x033C,  ur,60 ,  7,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,       perm_reg, 4, 4, 4,0x033D,  ur,61 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,smod_offset_table_0, 4, 4, 4,0x033E,  ur,62 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,smod_offset_table_1, 4, 4, 4,0x033F,  ur,63 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,smod_offset_table_2, 4, 4, 4,0x0340,  ur,64 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,smod_offset_table_3, 4, 4, 4,0x0341,  ur,65 , 32,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,       phasor_n, 4, 4, 4,0x0342,  ur,66 ,  4,0,0,0) \
 XCHAL_SA_REG(s,0,0,1,0,  phasor_offset, 4, 4, 4,0x0343,  ur,67 , 16,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu0,16,16,64,0x1008, ACU,0  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu1,16,16,64,0x1009, ACU,1  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu2,16,16,64,0x100A, ACU,2  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu3,16,16,64,0x100B, ACU,3  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu4,16,16,64,0x100C, ACU,4  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu5,16,16,64,0x100D, ACU,5  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu6,16,16,64,0x100E, ACU,6  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           acu7,16,16,64,0x100F, ACU,7  ,320,192,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm0,16,16,16,0x1010,  CM,0  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm1,16,16,16,0x1011,  CM,1  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm2,16,16,16,0x1012,  CM,2  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm3,16,16,16,0x1013,  CM,3  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm4,16,16,16,0x1014,  CM,4  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm5,16,16,16,0x1015,  CM,5  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm6,16,16,16,0x1016,  CM,6  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm7,16,16,16,0x1017,  CM,7  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm8,16,16,16,0x1018,  CM,8  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            cm9,16,16,16,0x1019,  CM,9  ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           cm10,16,16,16,0x101A,  CM,10 ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           cm11,16,16,16,0x101B,  CM,11 ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           cm12,16,16,16,0x101C,  CM,12 ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           cm13,16,16,16,0x101D,  CM,13 ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           cm14,16,16,16,0x101E,  CM,14 ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           cm15,16,16,16,0x101F,  CM,15 ,128,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq0,16,16,32,0x1020,  PQ,0  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq1,16,16,32,0x1021,  PQ,1  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq2,16,16,32,0x1022,  PQ,2  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq3,16,16,32,0x1023,  PQ,3  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq4,16,16,32,0x1024,  PQ,4  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq5,16,16,32,0x1025,  PQ,5  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq6,16,16,32,0x1026,  PQ,6  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq7,16,16,32,0x1027,  PQ,7  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq8,16,16,32,0x1028,  PQ,8  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,            pq9,16,16,32,0x1029,  PQ,9  ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           pq10,16,16,32,0x102A,  PQ,10 ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           pq11,16,16,32,0x102B,  PQ,11 ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           pq12,16,16,32,0x102C,  PQ,12 ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           pq13,16,16,32,0x102D,  PQ,13 ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           pq14,16,16,32,0x102E,  PQ,14 ,256,0,0,0) \
 XCHAL_SA_REG(s,0,0,2,0,           pq15,16,16,32,0x102F,  PQ,15 ,256,0,0,0)

#define XCHAL_CP3_SA_NUM	0
#define XCHAL_CP3_SA_LIST(s)	/* empty */

#define XCHAL_CP4_SA_NUM	0
#define XCHAL_CP4_SA_LIST(s)	/* empty */

#define XCHAL_CP5_SA_NUM	0
#define XCHAL_CP5_SA_LIST(s)	/* empty */

#define XCHAL_CP6_SA_NUM	0
#define XCHAL_CP6_SA_LIST(s)	/* empty */

#define XCHAL_CP7_SA_NUM	0
#define XCHAL_CP7_SA_LIST(s)	/* empty */

/* Byte length of instruction from its first nibble (op0 field), per FLIX.  */
#define XCHAL_OP0_FORMAT_LENGTHS	3,3,3,3,3,3,3,3,2,2,2,2,2,2,3,8

#endif /*_XTENSA_CORE_TIE_H*/

