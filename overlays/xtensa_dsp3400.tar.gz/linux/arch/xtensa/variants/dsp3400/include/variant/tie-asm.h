/* 
 * tie-asm.h -- compile-time HAL assembler definitions dependent on CORE & TIE
 *
 *  NOTE:  This header file is not meant to be included directly.
 */

/* This header file contains assembly-language definitions (assembly
   macros, etc.) for this specific Xtensa processor's TIE extensions
   and options.  It is customized to this Xtensa processor configuration.

   Copyright (c) 1999-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */

#ifndef _XTENSA_CORE_TIE_ASM_H
#define _XTENSA_CORE_TIE_ASM_H

/*  Selection parameter values for save-area save/restore macros:  */
/*  Option vs. TIE:  */
#define XTHAL_SAS_TIE	0x0001	/* custom extension or coprocessor */
#define XTHAL_SAS_OPT	0x0002	/* optional (and not a coprocessor) */
/*  Whether used automatically by compiler:  */
#define XTHAL_SAS_NOCC	0x0004	/* not used by compiler w/o special opts/code */
#define XTHAL_SAS_CC	0x0008	/* used by compiler without special opts/code */
/*  ABI handling across function calls:  */
#define XTHAL_SAS_CALR	0x0010	/* caller-saved */
#define XTHAL_SAS_CALE	0x0020	/* callee-saved */
#define XTHAL_SAS_GLOB	0x0040	/* global across function calls (in thread) */
/*  Misc  */
#define XTHAL_SAS_ALL	0xFFFF	/* include all default NCP contents */



/* Macro to save all non-coprocessor (extra) custom TIE and optional state
 * (not including zero-overhead loop registers).
 * Save area ptr (clobbered):  ptr  (4 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_NCP_NUM_ATMPS needed)
 */
	.macro xchal_ncp_store  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start	\continue, \ofs
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	rsr	\at1, BR		// boolean option
	s32i	\at1, \ptr, .Lxchal_ofs_ + 0
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	rsr	\at1, SCOMPARE1		// conditional store option
	s32i	\at1, \ptr, .Lxchal_ofs_ + 0
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_CC | XTHAL_SAS_GLOB) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	rur	\at1, THREADPTR		// threadptr option
	s32i	\at1, \ptr, .Lxchal_ofs_ + 0
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.endm	// xchal_ncp_store

/* Macro to save all non-coprocessor (extra) custom TIE and optional state
 * (not including zero-overhead loop registers).
 * Save area ptr (clobbered):  ptr  (4 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_NCP_NUM_ATMPS needed)
 */
	.macro xchal_ncp_load  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start	\continue, \ofs
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	l32i	\at1, \ptr, .Lxchal_ofs_ + 0
	wsr	\at1, BR		// boolean option
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	l32i	\at1, \ptr, .Lxchal_ofs_ + 0
	wsr	\at1, SCOMPARE1		// conditional store option
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_CC | XTHAL_SAS_GLOB) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	l32i	\at1, \ptr, .Lxchal_ofs_ + 0
	wur	\at1, THREADPTR		// threadptr option
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.endm	// xchal_ncp_load



#define XCHAL_NCP_NUM_ATMPS	1



/* Macro to save the state of TIE coprocessor FPU.
 * Save area ptr (clobbered):  ptr  (16 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_CP0_NUM_ATMPS needed)
 */
#define xchal_cp_FPU_store	xchal_cp0_store
/* #define xchal_cp_FPU_store_a2	xchal_cp0_store a2 a3 a4 a5 a6 */
	.macro	xchal_cp0_store  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start \continue, \ofs
	.ifeq (XTHAL_SAS_TIE | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 0, 1, 16
	rur232	\at1		// FCR
	s32i	\at1, \ptr, 0
	rur233	\at1		// FSR
	s32i	\at1, \ptr, 4
	SSI f0, \ptr,  8
	SSI f1, \ptr,  12
	SSI f2, \ptr,  16
	SSI f3, \ptr,  20
	SSI f4, \ptr,  24
	SSI f5, \ptr,  28
	SSI f6, \ptr,  32
	SSI f7, \ptr,  36
	SSI f8, \ptr,  40
	SSI f9, \ptr,  44
	SSI f10, \ptr,  48
	SSI f11, \ptr,  52
	SSI f12, \ptr,  56
	SSI f13, \ptr,  60
	SSI f14, \ptr,  64
	SSI f15, \ptr,  68
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 72
	.endif
	.endm	// xchal_cp0_store

/* Macro to restore the state of TIE coprocessor FPU.
 * Save area ptr (clobbered):  ptr  (16 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_CP0_NUM_ATMPS needed)
 */
#define xchal_cp_FPU_load	xchal_cp0_load
/* #define xchal_cp_FPU_load_a2	xchal_cp0_load a2 a3 a4 a5 a6 */
	.macro	xchal_cp0_load  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start \continue, \ofs
	.ifeq (XTHAL_SAS_TIE | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 0, 1, 16
	l32i	\at1, \ptr, 0
	wur232	\at1		// FCR
	l32i	\at1, \ptr, 4
	wur233	\at1		// FSR
	LSI f0, \ptr,  8
	LSI f1, \ptr,  12
	LSI f2, \ptr,  16
	LSI f3, \ptr,  20
	LSI f4, \ptr,  24
	LSI f5, \ptr,  28
	LSI f6, \ptr,  32
	LSI f7, \ptr,  36
	LSI f8, \ptr,  40
	LSI f9, \ptr,  44
	LSI f10, \ptr,  48
	LSI f11, \ptr,  52
	LSI f12, \ptr,  56
	LSI f13, \ptr,  60
	LSI f14, \ptr,  64
	LSI f15, \ptr,  68
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 72
	.endif
	.endm	// xchal_cp0_load

#define XCHAL_CP0_NUM_ATMPS	1

/* Macro to save the state of TIE coprocessor dsp3400copro_state.
 * Save area ptr (clobbered):  ptr  (16 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_CP2_NUM_ATMPS needed)
 */
#define xchal_cp_dsp3400copro_state_store	xchal_cp2_store
/* #define xchal_cp_dsp3400copro_state_store_a2	xchal_cp2_store a2 a3 a4 a5 a6 */
	.macro	xchal_cp2_store  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start \continue, \ofs
	.ifeq (XTHAL_SAS_TIE | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 0, 1, 16
	rur1	\at1		// SOV
	s32i	\at1, \ptr, 0
	rur2	\at1		// SAT_MODE
	s32i	\at1, \ptr, 4
	rur3	\at1		// SAR0
	s32i	\at1, \ptr, 8
	rur4	\at1		// SAR1
	s32i	\at1, \ptr, 12
	rur5	\at1		// SAR2
	s32i	\at1, \ptr, 16
	rur6	\at1		// SAR3
	s32i	\at1, \ptr, 20
	rur7	\at1		// HSAR0
	s32i	\at1, \ptr, 24
	rur8	\at1		// HSAR1
	s32i	\at1, \ptr, 28
	rur9	\at1		// HSAR2
	s32i	\at1, \ptr, 32
	rur10	\at1		// HSAR3
	s32i	\at1, \ptr, 36
	rur11	\at1		// MAX_REG_0
	s32i	\at1, \ptr, 40
	rur12	\at1		// MAX_REG_1
	s32i	\at1, \ptr, 44
	rur13	\at1		// MAX_REG_2
	s32i	\at1, \ptr, 48
	rur14	\at1		// MAX_REG_3
	s32i	\at1, \ptr, 52
	rur15	\at1		// ARG_MAX_REG_0
	s32i	\at1, \ptr, 56
	rur16	\at1		// ARG_MAX_REG_1
	s32i	\at1, \ptr, 60
	rur17	\at1		// ARG_MAX_REG_2
	s32i	\at1, \ptr, 64
	rur18	\at1		// ARG_MAX_REG_3
	s32i	\at1, \ptr, 68
	rur19	\at1		// NCO_COUNTER_0
	s32i	\at1, \ptr, 72
	rur20	\at1		// NCO_COUNTER_1
	s32i	\at1, \ptr, 76
	rur21	\at1		// NCO_COUNTER_2
	s32i	\at1, \ptr, 80
	rur22	\at1		// NCO_COUNTER_3
	s32i	\at1, \ptr, 84
	rur23	\at1		// INTERP_EXT_N
	s32i	\at1, \ptr, 88
	rur24	\at1		// INTERP_EXT_L
	s32i	\at1, \ptr, 92
	rur25	\at1		// LLR_BUF_0
	s32i	\at1, \ptr, 96
	rur26	\at1		// LLR_BUF_1
	s32i	\at1, \ptr, 100
	rur27	\at1		// LLR_BUF_2
	s32i	\at1, \ptr, 104
	rur28	\at1		// LLR_BUF_3
	s32i	\at1, \ptr, 108
	rur29	\at1		// LLR_BUF_4
	s32i	\at1, \ptr, 112
	rur30	\at1		// LLR_BUF_5
	s32i	\at1, \ptr, 116
	rur31	\at1		// LLR_BUF_6
	s32i	\at1, \ptr, 120
	rur32	\at1		// LLR_BUF_7
	s32i	\at1, \ptr, 124
	rur33	\at1		// LLR_BUF_8
	s32i	\at1, \ptr, 128
	rur34	\at1		// LLR_BUF_9
	s32i	\at1, \ptr, 132
	rur35	\at1		// LLR_BUF_10
	s32i	\at1, \ptr, 136
	rur36	\at1		// LLR_BUF_11
	s32i	\at1, \ptr, 140
	rur37	\at1		// LLR_BUF_12
	s32i	\at1, \ptr, 144
	rur38	\at1		// LLR_BUF_13
	s32i	\at1, \ptr, 148
	rur39	\at1		// LLR_BUF_14
	s32i	\at1, \ptr, 152
	rur40	\at1		// LLR_BUF_15
	s32i	\at1, \ptr, 156
	rur41	\at1		// LLR_BUF_16
	s32i	\at1, \ptr, 160
	rur42	\at1		// LLR_BUF_17
	s32i	\at1, \ptr, 164
	rur43	\at1		// LLR_BUF_18
	s32i	\at1, \ptr, 168
	rur44	\at1		// LLR_BUF_19
	s32i	\at1, \ptr, 172
	rur45	\at1		// LLR_BUF_20
	s32i	\at1, \ptr, 176
	rur46	\at1		// LLR_BUF_21
	s32i	\at1, \ptr, 180
	rur47	\at1		// LLR_BUF_22
	s32i	\at1, \ptr, 184
	rur48	\at1		// LLR_BUF_23
	s32i	\at1, \ptr, 188
	rur49	\at1		// SMOD_BUF_0
	s32i	\at1, \ptr, 192
	rur50	\at1		// SMOD_BUF_1
	s32i	\at1, \ptr, 196
	rur51	\at1		// SMOD_BUF_2
	s32i	\at1, \ptr, 200
	rur52	\at1		// SMOD_BUF_3
	s32i	\at1, \ptr, 204
	rur53	\at1		// SMOD_BUF_4
	s32i	\at1, \ptr, 208
	rur54	\at1		// SMOD_BUF_5
	s32i	\at1, \ptr, 212
	rur55	\at1		// SMOD_BUF_6
	s32i	\at1, \ptr, 216
	rur56	\at1		// SMOD_BUF_7
	s32i	\at1, \ptr, 220
	rur57	\at1		// WEIGHT_REG
	s32i	\at1, \ptr, 224
	rur58	\at1		// SCALE_REG
	s32i	\at1, \ptr, 228
	rur59	\at1		// LLR_POS
	s32i	\at1, \ptr, 232
	rur60	\at1		// SMOD_POS
	s32i	\at1, \ptr, 236
	rur61	\at1		// PERM_REG
	s32i	\at1, \ptr, 240
	rur62	\at1		// SMOD_OFFSET_TABLE_0
	s32i	\at1, \ptr, 244
	rur63	\at1		// SMOD_OFFSET_TABLE_1
	s32i	\at1, \ptr, 248
	rur64	\at1		// SMOD_OFFSET_TABLE_2
	s32i	\at1, \ptr, 252
	rur65	\at1		// SMOD_OFFSET_TABLE_3
	s32i	\at1, \ptr, 256
	rur66	\at1		// PHASOR_N
	s32i	\at1, \ptr, 260
	rur67	\at1		// PHASOR_OFFSET
	s32i	\at1, \ptr, 264
	addi	\ptr, \ptr, 272
	SAC2X64_0 ACU0, \ptr,  0
	SAC2X64_1 ACU0, \ptr,  0 + 16
	SAC2X64_2 ACU0, \ptr,  0 + 32
	SAC2X64_3 ACU0, \ptr,  0 + 48
	SAC2X64_0 ACU1, \ptr,  64
	SAC2X64_1 ACU1, \ptr,  64 + 16
	SAC2X64_2 ACU1, \ptr,  64 + 32
	SAC2X64_3 ACU1, \ptr,  64 + 48
	SAC2X64_0 ACU2, \ptr,  128
	SAC2X64_1 ACU2, \ptr,  128 + 16
	SAC2X64_2 ACU2, \ptr,  128 + 32
	SAC2X64_3 ACU2, \ptr,  128 + 48
	SAC2X64_0 ACU3, \ptr,  192
	SAC2X64_1 ACU3, \ptr,  192 + 16
	SAC2X64_2 ACU3, \ptr,  192 + 32
	SAC2X64_3 ACU3, \ptr,  192 + 48
	addi	\ptr, \ptr, 256
	SAC2X64_0 ACU4, \ptr,  0
	SAC2X64_1 ACU4, \ptr,  0 + 16
	SAC2X64_2 ACU4, \ptr,  0 + 32
	SAC2X64_3 ACU4, \ptr,  0 + 48
	SAC2X64_0 ACU5, \ptr,  64
	SAC2X64_1 ACU5, \ptr,  64 + 16
	SAC2X64_2 ACU5, \ptr,  64 + 32
	SAC2X64_3 ACU5, \ptr,  64 + 48
	SAC2X64_0 ACU6, \ptr,  128
	SAC2X64_1 ACU6, \ptr,  128 + 16
	SAC2X64_2 ACU6, \ptr,  128 + 32
	SAC2X64_3 ACU6, \ptr,  128 + 48
	SAC2X64_0 ACU7, \ptr,  192
	SAC2X64_1 ACU7, \ptr,  192 + 16
	SAC2X64_2 ACU7, \ptr,  192 + 32
	SAC2X64_3 ACU7, \ptr,  192 + 48
	addi	\ptr, \ptr, 256
	SCM CM0, \ptr,  0
	SCM CM1, \ptr,  16
	SCM CM2, \ptr,  32
	SCM CM3, \ptr,  48
	SCM CM4, \ptr,  64
	SCM CM5, \ptr,  80
	SCM CM6, \ptr,  96
	SCM CM7, \ptr,  112
	SCM CM8, \ptr,  128
	SCM CM9, \ptr,  144
	SCM CM10, \ptr,  160
	SCM CM11, \ptr,  176
	SCM CM12, \ptr,  192
	SCM CM13, \ptr,  208
	SCM CM14, \ptr,  224
	SCM CM15, \ptr,  240
	addi	\ptr, \ptr, 256
	STORE_P PQ0, \ptr,  0
	STORE_Q PQ0, \ptr,  0 + 16
	STORE_P PQ1, \ptr,  32
	STORE_Q PQ1, \ptr,  32 + 16
	STORE_P PQ2, \ptr,  64
	STORE_Q PQ2, \ptr,  64 + 16
	STORE_P PQ3, \ptr,  96
	STORE_Q PQ3, \ptr,  96 + 16
	STORE_P PQ4, \ptr,  128
	STORE_Q PQ4, \ptr,  128 + 16
	STORE_P PQ5, \ptr,  160
	STORE_Q PQ5, \ptr,  160 + 16
	STORE_P PQ6, \ptr,  192
	STORE_Q PQ6, \ptr,  192 + 16
	STORE_P PQ7, \ptr,  224
	STORE_Q PQ7, \ptr,  224 + 16
	addi	\ptr, \ptr, 256
	STORE_P PQ8, \ptr,  0
	STORE_Q PQ8, \ptr,  0 + 16
	STORE_P PQ9, \ptr,  32
	STORE_Q PQ9, \ptr,  32 + 16
	STORE_P PQ10, \ptr,  64
	STORE_Q PQ10, \ptr,  64 + 16
	STORE_P PQ11, \ptr,  96
	STORE_Q PQ11, \ptr,  96 + 16
	STORE_P PQ12, \ptr,  128
	STORE_Q PQ12, \ptr,  128 + 16
	STORE_P PQ13, \ptr,  160
	STORE_Q PQ13, \ptr,  160 + 16
	STORE_P PQ14, \ptr,  192
	STORE_Q PQ14, \ptr,  192 + 16
	STORE_P PQ15, \ptr,  224
	STORE_Q PQ15, \ptr,  224 + 16
	.set	.Lxchal_pofs_, .Lxchal_pofs_ + 1296
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 1552
	.endif
	.endm	// xchal_cp2_store

/* Macro to restore the state of TIE coprocessor dsp3400copro_state.
 * Save area ptr (clobbered):  ptr  (16 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_CP2_NUM_ATMPS needed)
 */
#define xchal_cp_dsp3400copro_state_load	xchal_cp2_load
/* #define xchal_cp_dsp3400copro_state_load_a2	xchal_cp2_load a2 a3 a4 a5 a6 */
	.macro	xchal_cp2_load  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start \continue, \ofs
	.ifeq (XTHAL_SAS_TIE | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 0, 1, 16
	l32i	\at1, \ptr, 0
	wur1	\at1		// SOV
	l32i	\at1, \ptr, 4
	wur2	\at1		// SAT_MODE
	l32i	\at1, \ptr, 8
	wur3	\at1		// SAR0
	l32i	\at1, \ptr, 12
	wur4	\at1		// SAR1
	l32i	\at1, \ptr, 16
	wur5	\at1		// SAR2
	l32i	\at1, \ptr, 20
	wur6	\at1		// SAR3
	l32i	\at1, \ptr, 24
	wur7	\at1		// HSAR0
	l32i	\at1, \ptr, 28
	wur8	\at1		// HSAR1
	l32i	\at1, \ptr, 32
	wur9	\at1		// HSAR2
	l32i	\at1, \ptr, 36
	wur10	\at1		// HSAR3
	l32i	\at1, \ptr, 40
	wur11	\at1		// MAX_REG_0
	l32i	\at1, \ptr, 44
	wur12	\at1		// MAX_REG_1
	l32i	\at1, \ptr, 48
	wur13	\at1		// MAX_REG_2
	l32i	\at1, \ptr, 52
	wur14	\at1		// MAX_REG_3
	l32i	\at1, \ptr, 56
	wur15	\at1		// ARG_MAX_REG_0
	l32i	\at1, \ptr, 60
	wur16	\at1		// ARG_MAX_REG_1
	l32i	\at1, \ptr, 64
	wur17	\at1		// ARG_MAX_REG_2
	l32i	\at1, \ptr, 68
	wur18	\at1		// ARG_MAX_REG_3
	l32i	\at1, \ptr, 72
	wur19	\at1		// NCO_COUNTER_0
	l32i	\at1, \ptr, 76
	wur20	\at1		// NCO_COUNTER_1
	l32i	\at1, \ptr, 80
	wur21	\at1		// NCO_COUNTER_2
	l32i	\at1, \ptr, 84
	wur22	\at1		// NCO_COUNTER_3
	l32i	\at1, \ptr, 88
	wur23	\at1		// INTERP_EXT_N
	l32i	\at1, \ptr, 92
	wur24	\at1		// INTERP_EXT_L
	l32i	\at1, \ptr, 96
	wur25	\at1		// LLR_BUF_0
	l32i	\at1, \ptr, 100
	wur26	\at1		// LLR_BUF_1
	l32i	\at1, \ptr, 104
	wur27	\at1		// LLR_BUF_2
	l32i	\at1, \ptr, 108
	wur28	\at1		// LLR_BUF_3
	l32i	\at1, \ptr, 112
	wur29	\at1		// LLR_BUF_4
	l32i	\at1, \ptr, 116
	wur30	\at1		// LLR_BUF_5
	l32i	\at1, \ptr, 120
	wur31	\at1		// LLR_BUF_6
	l32i	\at1, \ptr, 124
	wur32	\at1		// LLR_BUF_7
	l32i	\at1, \ptr, 128
	wur33	\at1		// LLR_BUF_8
	l32i	\at1, \ptr, 132
	wur34	\at1		// LLR_BUF_9
	l32i	\at1, \ptr, 136
	wur35	\at1		// LLR_BUF_10
	l32i	\at1, \ptr, 140
	wur36	\at1		// LLR_BUF_11
	l32i	\at1, \ptr, 144
	wur37	\at1		// LLR_BUF_12
	l32i	\at1, \ptr, 148
	wur38	\at1		// LLR_BUF_13
	l32i	\at1, \ptr, 152
	wur39	\at1		// LLR_BUF_14
	l32i	\at1, \ptr, 156
	wur40	\at1		// LLR_BUF_15
	l32i	\at1, \ptr, 160
	wur41	\at1		// LLR_BUF_16
	l32i	\at1, \ptr, 164
	wur42	\at1		// LLR_BUF_17
	l32i	\at1, \ptr, 168
	wur43	\at1		// LLR_BUF_18
	l32i	\at1, \ptr, 172
	wur44	\at1		// LLR_BUF_19
	l32i	\at1, \ptr, 176
	wur45	\at1		// LLR_BUF_20
	l32i	\at1, \ptr, 180
	wur46	\at1		// LLR_BUF_21
	l32i	\at1, \ptr, 184
	wur47	\at1		// LLR_BUF_22
	l32i	\at1, \ptr, 188
	wur48	\at1		// LLR_BUF_23
	l32i	\at1, \ptr, 192
	wur49	\at1		// SMOD_BUF_0
	l32i	\at1, \ptr, 196
	wur50	\at1		// SMOD_BUF_1
	l32i	\at1, \ptr, 200
	wur51	\at1		// SMOD_BUF_2
	l32i	\at1, \ptr, 204
	wur52	\at1		// SMOD_BUF_3
	l32i	\at1, \ptr, 208
	wur53	\at1		// SMOD_BUF_4
	l32i	\at1, \ptr, 212
	wur54	\at1		// SMOD_BUF_5
	l32i	\at1, \ptr, 216
	wur55	\at1		// SMOD_BUF_6
	l32i	\at1, \ptr, 220
	wur56	\at1		// SMOD_BUF_7
	l32i	\at1, \ptr, 224
	wur57	\at1		// WEIGHT_REG
	l32i	\at1, \ptr, 228
	wur58	\at1		// SCALE_REG
	l32i	\at1, \ptr, 232
	wur59	\at1		// LLR_POS
	l32i	\at1, \ptr, 236
	wur60	\at1		// SMOD_POS
	l32i	\at1, \ptr, 240
	wur61	\at1		// PERM_REG
	l32i	\at1, \ptr, 244
	wur62	\at1		// SMOD_OFFSET_TABLE_0
	l32i	\at1, \ptr, 248
	wur63	\at1		// SMOD_OFFSET_TABLE_1
	l32i	\at1, \ptr, 252
	wur64	\at1		// SMOD_OFFSET_TABLE_2
	l32i	\at1, \ptr, 256
	wur65	\at1		// SMOD_OFFSET_TABLE_3
	l32i	\at1, \ptr, 260
	wur66	\at1		// PHASOR_N
	l32i	\at1, \ptr, 264
	wur67	\at1		// PHASOR_OFFSET
	addi	\ptr, \ptr, 1040
	LP PQ0, \ptr,  0
	LQ PQ0, \ptr,  0 + 16
	LP PQ1, \ptr,  32
	LQ PQ1, \ptr,  32 + 16
	LP PQ2, \ptr,  64
	LQ PQ2, \ptr,  64 + 16
	LP PQ3, \ptr,  96
	LQ PQ3, \ptr,  96 + 16
	LP PQ4, \ptr,  128
	LQ PQ4, \ptr,  128 + 16
	LP PQ5, \ptr,  160
	LQ PQ5, \ptr,  160 + 16
	LP PQ6, \ptr,  192
	LQ PQ6, \ptr,  192 + 16
	LP PQ7, \ptr,  224
	LQ PQ7, \ptr,  224 + 16
	LP PQ8, \ptr,  256
	LQ PQ8, \ptr,  256 + 16
	LP PQ9, \ptr,  288
	LQ PQ9, \ptr,  288 + 16
	LP PQ10, \ptr,  320
	LQ PQ10, \ptr,  320 + 16
	LP PQ11, \ptr,  352
	LQ PQ11, \ptr,  352 + 16
	LP PQ12, \ptr,  384
	LQ PQ12, \ptr,  384 + 16
	LP PQ13, \ptr,  416
	LQ PQ13, \ptr,  416 + 16
	LP PQ14, \ptr,  448
	LQ PQ14, \ptr,  448 + 16
	LP PQ15, \ptr,  480
	LQ PQ15, \ptr,  480 + 16
	addi	\ptr, \ptr, -256
	LCM CM0, \ptr,  0
	LCM CM1, \ptr,  16
	LCM CM2, \ptr,  32
	LCM CM3, \ptr,  48
	LCM CM4, \ptr,  64
	LCM CM5, \ptr,  80
	LCM CM6, \ptr,  96
	LCM CM7, \ptr,  112
	LCM CM8, \ptr,  128
	LCM CM9, \ptr,  144
	LCM CM10, \ptr,  160
	LCM CM11, \ptr,  176
	LCM CM12, \ptr,  192
	LCM CM13, \ptr,  208
	LCM CM14, \ptr,  224
	LCM CM15, \ptr,  240
	addi	\ptr, \ptr, -512
	LAC2X64_0 ACU0, \ptr,  0
	LAC2X64_1 ACU0, \ptr,  0 + 16
	LAC2X64_2 ACU0, \ptr,  0 + 32
	LAC2X64_3 ACU0, \ptr,  0 + 48
	LAC2X64_0 ACU1, \ptr,  64
	LAC2X64_1 ACU1, \ptr,  64 + 16
	LAC2X64_2 ACU1, \ptr,  64 + 32
	LAC2X64_3 ACU1, \ptr,  64 + 48
	LAC2X64_0 ACU2, \ptr,  128
	LAC2X64_1 ACU2, \ptr,  128 + 16
	LAC2X64_2 ACU2, \ptr,  128 + 32
	LAC2X64_3 ACU2, \ptr,  128 + 48
	LAC2X64_0 ACU3, \ptr,  192
	LAC2X64_1 ACU3, \ptr,  192 + 16
	LAC2X64_2 ACU3, \ptr,  192 + 32
	LAC2X64_3 ACU3, \ptr,  192 + 48
	addi	\ptr, \ptr, 256
	LAC2X64_0 ACU4, \ptr,  0
	LAC2X64_1 ACU4, \ptr,  0 + 16
	LAC2X64_2 ACU4, \ptr,  0 + 32
	LAC2X64_3 ACU4, \ptr,  0 + 48
	LAC2X64_0 ACU5, \ptr,  64
	LAC2X64_1 ACU5, \ptr,  64 + 16
	LAC2X64_2 ACU5, \ptr,  64 + 32
	LAC2X64_3 ACU5, \ptr,  64 + 48
	LAC2X64_0 ACU6, \ptr,  128
	LAC2X64_1 ACU6, \ptr,  128 + 16
	LAC2X64_2 ACU6, \ptr,  128 + 32
	LAC2X64_3 ACU6, \ptr,  128 + 48
	LAC2X64_0 ACU7, \ptr,  192
	LAC2X64_1 ACU7, \ptr,  192 + 16
	LAC2X64_2 ACU7, \ptr,  192 + 32
	LAC2X64_3 ACU7, \ptr,  192 + 48
	.set	.Lxchal_pofs_, .Lxchal_pofs_ + 528
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 1552
	.endif
	.endm	// xchal_cp2_load

#define XCHAL_CP2_NUM_ATMPS	1
#define XCHAL_SA_NUM_ATMPS	1

	/*  Empty macros for unconfigured coprocessors:  */
	.macro xchal_cp1_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp1_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp3_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp3_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp4_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp4_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp5_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp5_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp6_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp6_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp7_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp7_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm

#endif /*_XTENSA_CORE_TIE_ASM_H*/

