/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	1632

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   44, 176,   0,   0,  4, -1, 0x0204, "br" },
  {   45, 180,   4,   4,  4, -1, 0x020c, "scompare1" },
  {   47, 188,   8,  16,  4,  0, 0x0030, "f0" },
  {   48, 192,  12,  20,  4,  0, 0x0031, "f1" },
  {   49, 196,  16,  24,  4,  0, 0x0032, "f2" },
  {   50, 200,  20,  28,  4,  0, 0x0033, "f3" },
  {   51, 204,  24,  32,  4,  0, 0x0034, "f4" },
  {   52, 208,  28,  36,  4,  0, 0x0035, "f5" },
  {   53, 212,  32,  40,  4,  0, 0x0036, "f6" },
  {   54, 216,  36,  44,  4,  0, 0x0037, "f7" },
  {   55, 220,  40,  48,  4,  0, 0x0038, "f8" },
  {   56, 224,  44,  52,  4,  0, 0x0039, "f9" },
  {   57, 228,  48,  56,  4,  0, 0x003a, "f10" },
  {   58, 232,  52,  60,  4,  0, 0x003b, "f11" },
  {   59, 236,  56,  64,  4,  0, 0x003c, "f12" },
  {   60, 240,  60,  68,  4,  0, 0x003d, "f13" },
  {   61, 244,  64,  72,  4,  0, 0x003e, "f14" },
  {   62, 248,  68,  76,  4,  0, 0x003f, "f15" },
  {   63, 252,   0,   8,  4,  0, 0x03e8, "fcr" },
  {   64, 256,   4,  12,  4,  0, 0x03e9, "fsr" },
  {   65, 260,   0,  80,  4,  2, 0x0301, "sov" },
  {   66, 264,   4,  84,  4,  2, 0x0302, "sat_mode" },
  {   67, 268,   8,  88,  4,  2, 0x0303, "sar0" },
  {   68, 272,  12,  92,  4,  2, 0x0304, "sar1" },
  {   69, 276,  16,  96,  4,  2, 0x0305, "sar2" },
  {   70, 280,  20, 100,  4,  2, 0x0306, "sar3" },
  {   71, 284,  24, 104,  4,  2, 0x0307, "hsar0" },
  {   72, 288,  28, 108,  4,  2, 0x0308, "hsar1" },
  {   73, 292,  32, 112,  4,  2, 0x0309, "hsar2" },
  {   74, 296,  36, 116,  4,  2, 0x030a, "hsar3" },
  {   75, 300,  40, 120,  4,  2, 0x030b, "max_reg_0" },
  {   76, 304,  44, 124,  4,  2, 0x030c, "max_reg_1" },
  {   77, 308,  48, 128,  4,  2, 0x030d, "max_reg_2" },
  {   78, 312,  52, 132,  4,  2, 0x030e, "max_reg_3" },
  {   79, 316,  56, 136,  4,  2, 0x030f, "arg_max_reg_0" },
  {   80, 320,  60, 140,  4,  2, 0x0310, "arg_max_reg_1" },
  {   81, 324,  64, 144,  4,  2, 0x0311, "arg_max_reg_2" },
  {   82, 328,  68, 148,  4,  2, 0x0312, "arg_max_reg_3" },
  {   83, 332,  72, 152,  4,  2, 0x0313, "nco_counter_0" },
  {   84, 336,  76, 156,  4,  2, 0x0314, "nco_counter_1" },
  {   85, 340,  80, 160,  4,  2, 0x0315, "nco_counter_2" },
  {   86, 344,  84, 164,  4,  2, 0x0316, "nco_counter_3" },
  {   87, 348,  88, 168,  4,  2, 0x0317, "interp_ext_n" },
  {   88, 352,  92, 172,  4,  2, 0x0318, "interp_ext_l" },
  {   89, 356,  96, 176,  4,  2, 0x0319, "llr_buf_0" },
  {   90, 360, 100, 180,  4,  2, 0x031a, "llr_buf_1" },
  {   91, 364, 104, 184,  4,  2, 0x031b, "llr_buf_2" },
  {   92, 368, 108, 188,  4,  2, 0x031c, "llr_buf_3" },
  {   93, 372, 112, 192,  4,  2, 0x031d, "llr_buf_4" },
  {   94, 376, 116, 196,  4,  2, 0x031e, "llr_buf_5" },
  {   95, 380, 120, 200,  4,  2, 0x031f, "llr_buf_6" },
  {   96, 384, 124, 204,  4,  2, 0x0320, "llr_buf_7" },
  {   97, 388, 128, 208,  4,  2, 0x0321, "llr_buf_8" },
  {   98, 392, 132, 212,  4,  2, 0x0322, "llr_buf_9" },
  {   99, 396, 136, 216,  4,  2, 0x0323, "llr_buf_10" },
  {  100, 400, 140, 220,  4,  2, 0x0324, "llr_buf_11" },
  {  101, 404, 144, 224,  4,  2, 0x0325, "llr_buf_12" },
  {  102, 408, 148, 228,  4,  2, 0x0326, "llr_buf_13" },
  {  103, 412, 152, 232,  4,  2, 0x0327, "llr_buf_14" },
  {  104, 416, 156, 236,  4,  2, 0x0328, "llr_buf_15" },
  {  105, 420, 160, 240,  4,  2, 0x0329, "llr_buf_16" },
  {  106, 424, 164, 244,  4,  2, 0x032a, "llr_buf_17" },
  {  107, 428, 168, 248,  4,  2, 0x032b, "llr_buf_18" },
  {  108, 432, 172, 252,  4,  2, 0x032c, "llr_buf_19" },
  {  109, 436, 176, 256,  4,  2, 0x032d, "llr_buf_20" },
  {  110, 440, 180, 260,  4,  2, 0x032e, "llr_buf_21" },
  {  111, 444, 184, 264,  4,  2, 0x032f, "llr_buf_22" },
  {  112, 448, 188, 268,  4,  2, 0x0330, "llr_buf_23" },
  {  113, 452, 192, 272,  4,  2, 0x0331, "smod_buf_0" },
  {  114, 456, 196, 276,  4,  2, 0x0332, "smod_buf_1" },
  {  115, 460, 200, 280,  4,  2, 0x0333, "smod_buf_2" },
  {  116, 464, 204, 284,  4,  2, 0x0334, "smod_buf_3" },
  {  117, 468, 208, 288,  4,  2, 0x0335, "smod_buf_4" },
  {  118, 472, 212, 292,  4,  2, 0x0336, "smod_buf_5" },
  {  119, 476, 216, 296,  4,  2, 0x0337, "smod_buf_6" },
  {  120, 480, 220, 300,  4,  2, 0x0338, "smod_buf_7" },
  {  121, 484, 224, 304,  4,  2, 0x0339, "weight_reg" },
  {  122, 488, 228, 308,  4,  2, 0x033a, "scale_reg" },
  {  123, 492, 232, 312,  4,  2, 0x033b, "llr_pos" },
  {  124, 496, 236, 316,  4,  2, 0x033c, "smod_pos" },
  {  125, 500, 240, 320,  4,  2, 0x033d, "perm_reg" },
  {  126, 504, 244, 324,  4,  2, 0x033e, "smod_offset_table_0" },
  {  127, 508, 248, 328,  4,  2, 0x033f, "smod_offset_table_1" },
  {  128, 512, 252, 332,  4,  2, 0x0340, "smod_offset_table_2" },
  {  129, 516, 256, 336,  4,  2, 0x0341, "smod_offset_table_3" },
  {  130, 520, 260, 340,  4,  2, 0x0342, "phasor_n" },
  {  131, 524, 264, 344,  4,  2, 0x0343, "phasor_offset" },
  {  132, 528, 272, 352, 64,  2, 0x1008, "acu0" },
  {  133, 592, 336, 416, 64,  2, 0x1009, "acu1" },
  {  134, 656, 400, 480, 64,  2, 0x100a, "acu2" },
  {  135, 720, 464, 544, 64,  2, 0x100b, "acu3" },
  {  136, 784, 528, 608, 64,  2, 0x100c, "acu4" },
  {  137, 848, 592, 672, 64,  2, 0x100d, "acu5" },
  {  138, 912, 656, 736, 64,  2, 0x100e, "acu6" },
  {  139, 976, 720, 800, 64,  2, 0x100f, "acu7" },
  {  140,1040, 784, 864, 16,  2, 0x1010, "cm0" },
  {  141,1056, 800, 880, 16,  2, 0x1011, "cm1" },
  {  142,1072, 816, 896, 16,  2, 0x1012, "cm2" },
  {  143,1088, 832, 912, 16,  2, 0x1013, "cm3" },
  {  144,1104, 848, 928, 16,  2, 0x1014, "cm4" },
  {  145,1120, 864, 944, 16,  2, 0x1015, "cm5" },
  {  146,1136, 880, 960, 16,  2, 0x1016, "cm6" },
  {  147,1152, 896, 976, 16,  2, 0x1017, "cm7" },
  {  148,1168, 912, 992, 16,  2, 0x1018, "cm8" },
  {  149,1184, 928,1008, 16,  2, 0x1019, "cm9" },
  {  150,1200, 944,1024, 16,  2, 0x101a, "cm10" },
  {  151,1216, 960,1040, 16,  2, 0x101b, "cm11" },
  {  152,1232, 976,1056, 16,  2, 0x101c, "cm12" },
  {  153,1248, 992,1072, 16,  2, 0x101d, "cm13" },
  {  154,1264,1008,1088, 16,  2, 0x101e, "cm14" },
  {  155,1280,1024,1104, 16,  2, 0x101f, "cm15" },
  {  156,1296,1040,1120, 32,  2, 0x1020, "pq0" },
  {  157,1328,1072,1152, 32,  2, 0x1021, "pq1" },
  {  158,1360,1104,1184, 32,  2, 0x1022, "pq2" },
  {  159,1392,1136,1216, 32,  2, 0x1023, "pq3" },
  {  160,1424,1168,1248, 32,  2, 0x1024, "pq4" },
  {  161,1456,1200,1280, 32,  2, 0x1025, "pq5" },
  {  162,1488,1232,1312, 32,  2, 0x1026, "pq6" },
  {  163,1520,1264,1344, 32,  2, 0x1027, "pq7" },
  {  164,1552,1296,1376, 32,  2, 0x1028, "pq8" },
  {  165,1584,1328,1408, 32,  2, 0x1029, "pq9" },
  {  166,1616,1360,1440, 32,  2, 0x102a, "pq10" },
  {  167,1648,1392,1472, 32,  2, 0x102b, "pq11" },
  {  168,1680,1424,1504, 32,  2, 0x102c, "pq12" },
  {  169,1712,1456,1536, 32,  2, 0x102d, "pq13" },
  {  170,1744,1488,1568, 32,  2, 0x102e, "pq14" },
  {  171,1776,1520,1600, 32,  2, 0x102f, "pq15" },
  { 0 }
};

