/* Configuration for the Xtensa architecture for GDB, the GNU debugger.

   Copyright (c) 2003-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */

#define XTENSA_CONFIG_VERSION 0x60

#include "defs.h"
#include "xtensa-config.h"
#include "xtensa-tdep.h"



/* Masked registers.  */
xtensa_reg_mask_t xtensa_submask0[] = { { 44, 0, 1 } };
const xtensa_mask_t xtensa_mask0 = { 1, xtensa_submask0 };
xtensa_reg_mask_t xtensa_submask1[] = { { 44, 1, 1 } };
const xtensa_mask_t xtensa_mask1 = { 1, xtensa_submask1 };
xtensa_reg_mask_t xtensa_submask2[] = { { 44, 2, 1 } };
const xtensa_mask_t xtensa_mask2 = { 1, xtensa_submask2 };
xtensa_reg_mask_t xtensa_submask3[] = { { 44, 3, 1 } };
const xtensa_mask_t xtensa_mask3 = { 1, xtensa_submask3 };
xtensa_reg_mask_t xtensa_submask4[] = { { 44, 4, 1 } };
const xtensa_mask_t xtensa_mask4 = { 1, xtensa_submask4 };
xtensa_reg_mask_t xtensa_submask5[] = { { 44, 5, 1 } };
const xtensa_mask_t xtensa_mask5 = { 1, xtensa_submask5 };
xtensa_reg_mask_t xtensa_submask6[] = { { 44, 6, 1 } };
const xtensa_mask_t xtensa_mask6 = { 1, xtensa_submask6 };
xtensa_reg_mask_t xtensa_submask7[] = { { 44, 7, 1 } };
const xtensa_mask_t xtensa_mask7 = { 1, xtensa_submask7 };
xtensa_reg_mask_t xtensa_submask8[] = { { 44, 8, 1 } };
const xtensa_mask_t xtensa_mask8 = { 1, xtensa_submask8 };
xtensa_reg_mask_t xtensa_submask9[] = { { 44, 9, 1 } };
const xtensa_mask_t xtensa_mask9 = { 1, xtensa_submask9 };
xtensa_reg_mask_t xtensa_submask10[] = { { 44, 10, 1 } };
const xtensa_mask_t xtensa_mask10 = { 1, xtensa_submask10 };
xtensa_reg_mask_t xtensa_submask11[] = { { 44, 11, 1 } };
const xtensa_mask_t xtensa_mask11 = { 1, xtensa_submask11 };
xtensa_reg_mask_t xtensa_submask12[] = { { 44, 12, 1 } };
const xtensa_mask_t xtensa_mask12 = { 1, xtensa_submask12 };
xtensa_reg_mask_t xtensa_submask13[] = { { 44, 13, 1 } };
const xtensa_mask_t xtensa_mask13 = { 1, xtensa_submask13 };
xtensa_reg_mask_t xtensa_submask14[] = { { 44, 14, 1 } };
const xtensa_mask_t xtensa_mask14 = { 1, xtensa_submask14 };
xtensa_reg_mask_t xtensa_submask15[] = { { 44, 15, 1 } };
const xtensa_mask_t xtensa_mask15 = { 1, xtensa_submask15 };
xtensa_reg_mask_t xtensa_submask16[] = { { 42, 0, 4 } };
const xtensa_mask_t xtensa_mask16 = { 1, xtensa_submask16 };
xtensa_reg_mask_t xtensa_submask17[] = { { 42, 5, 1 } };
const xtensa_mask_t xtensa_mask17 = { 1, xtensa_submask17 };
xtensa_reg_mask_t xtensa_submask18[] = { { 42, 18, 1 } };
const xtensa_mask_t xtensa_mask18 = { 1, xtensa_submask18 };
xtensa_reg_mask_t xtensa_submask19[] = { { 42, 4, 1 } };
const xtensa_mask_t xtensa_mask19 = { 1, xtensa_submask19 };
xtensa_reg_mask_t xtensa_submask20[] = { { 42, 16, 2 } };
const xtensa_mask_t xtensa_mask20 = { 1, xtensa_submask20 };
xtensa_reg_mask_t xtensa_submask21[] = { { 42, 8, 4 } };
const xtensa_mask_t xtensa_mask21 = { 1, xtensa_submask21 };
xtensa_reg_mask_t xtensa_submask22[] = { { 37, 12, 20 } };
const xtensa_mask_t xtensa_mask22 = { 1, xtensa_submask22 };
xtensa_reg_mask_t xtensa_submask23[] = { { 37, 0, 1 } };
const xtensa_mask_t xtensa_mask23 = { 1, xtensa_submask23 };
xtensa_reg_mask_t xtensa_submask24[] = { { 207, 8, 4 } };
const xtensa_mask_t xtensa_mask24 = { 1, xtensa_submask24 };
xtensa_reg_mask_t xtensa_submask25[] = { { 63, 0, 2 } };
const xtensa_mask_t xtensa_mask25 = { 1, xtensa_submask25 };
xtensa_reg_mask_t xtensa_submask26[] = { { 63, 6, 1 } };
const xtensa_mask_t xtensa_mask26 = { 1, xtensa_submask26 };
xtensa_reg_mask_t xtensa_submask27[] = { { 63, 5, 1 } };
const xtensa_mask_t xtensa_mask27 = { 1, xtensa_submask27 };
xtensa_reg_mask_t xtensa_submask28[] = { { 63, 4, 1 } };
const xtensa_mask_t xtensa_mask28 = { 1, xtensa_submask28 };
xtensa_reg_mask_t xtensa_submask29[] = { { 63, 3, 1 } };
const xtensa_mask_t xtensa_mask29 = { 1, xtensa_submask29 };
xtensa_reg_mask_t xtensa_submask30[] = { { 63, 2, 1 } };
const xtensa_mask_t xtensa_mask30 = { 1, xtensa_submask30 };
xtensa_reg_mask_t xtensa_submask31[] = { { 64, 11, 1 } };
const xtensa_mask_t xtensa_mask31 = { 1, xtensa_submask31 };
xtensa_reg_mask_t xtensa_submask32[] = { { 64, 10, 1 } };
const xtensa_mask_t xtensa_mask32 = { 1, xtensa_submask32 };
xtensa_reg_mask_t xtensa_submask33[] = { { 64, 9, 1 } };
const xtensa_mask_t xtensa_mask33 = { 1, xtensa_submask33 };
xtensa_reg_mask_t xtensa_submask34[] = { { 64, 8, 1 } };
const xtensa_mask_t xtensa_mask34 = { 1, xtensa_submask34 };
xtensa_reg_mask_t xtensa_submask35[] = { { 64, 7, 1 } };
const xtensa_mask_t xtensa_mask35 = { 1, xtensa_submask35 };
xtensa_reg_mask_t xtensa_submask36[] = { { 63, 12, 20 } };
const xtensa_mask_t xtensa_mask36 = { 1, xtensa_submask36 };
xtensa_reg_mask_t xtensa_submask37[] = { { 64, 12, 20 } };
const xtensa_mask_t xtensa_mask37 = { 1, xtensa_submask37 };
xtensa_reg_mask_t xtensa_submask38[] = { { 63, 7, 5 } };
const xtensa_mask_t xtensa_mask38 = { 1, xtensa_submask38 };
xtensa_reg_mask_t xtensa_submask39[] = { { 64, 0, 7 } };
const xtensa_mask_t xtensa_mask39 = { 1, xtensa_submask39 };
xtensa_reg_mask_t xtensa_submask40[] = { { 75, 0, 32 }, { 76, 0, 32 }, { 77, 0, 32 }, { 78, 0, 32 } };
const xtensa_mask_t xtensa_mask40 = { 4, xtensa_submask40 };
xtensa_reg_mask_t xtensa_submask41[] = { { 79, 0, 32 }, { 80, 0, 32 }, { 81, 0, 32 }, { 82, 0, 32 } };
const xtensa_mask_t xtensa_mask41 = { 4, xtensa_submask41 };
xtensa_reg_mask_t xtensa_submask42[] = { { 83, 0, 32 }, { 84, 0, 32 }, { 85, 0, 32 }, { 86, 0, 32 } };
const xtensa_mask_t xtensa_mask42 = { 4, xtensa_submask42 };
xtensa_reg_mask_t xtensa_submask43[] = { { 89, 0, 32 }, { 90, 0, 32 }, { 91, 0, 32 }, { 92, 0, 32 }, { 93, 0, 32 }, { 94, 0, 32 }, { 95, 0, 32 }, { 96, 0, 32 }, { 97, 0, 32 }, { 98, 0, 32 }, { 99, 0, 32 }, { 100, 0, 32 }, { 101, 0, 32 }, { 102, 0, 32 }, { 103, 0, 32 }, { 104, 0, 32 }, { 105, 0, 32 }, { 106, 0, 32 }, { 107, 0, 32 }, { 108, 0, 32 }, { 109, 0, 32 }, { 110, 0, 32 }, { 111, 0, 32 }, { 112, 0, 32 } };
const xtensa_mask_t xtensa_mask43 = { 24, xtensa_submask43 };
xtensa_reg_mask_t xtensa_submask44[] = { { 113, 0, 32 }, { 114, 0, 32 }, { 115, 0, 32 }, { 116, 0, 32 }, { 117, 0, 32 }, { 118, 0, 32 }, { 119, 0, 32 }, { 120, 0, 32 } };
const xtensa_mask_t xtensa_mask44 = { 8, xtensa_submask44 };
xtensa_reg_mask_t xtensa_submask45[] = { { 126, 0, 32 }, { 127, 0, 32 }, { 128, 0, 32 }, { 129, 0, 32 } };
const xtensa_mask_t xtensa_mask45 = { 4, xtensa_submask45 };


/* Register map.  */
xtensa_register_t rmap[] = 
{
  /*    idx ofs bi sz al targno  flags cp typ group name  */
  XTREG(  0,  0,32, 4, 4,0x0020,0x0006,-2, 9,0x0100,pc,          0,0,0,0,0,0)
  XTREG(  1,  4,32, 4, 4,0x0100,0x0006,-2, 1,0x0002,ar0,         0,0,0,0,0,0)
  XTREG(  2,  8,32, 4, 4,0x0101,0x0006,-2, 1,0x0002,ar1,         0,0,0,0,0,0)
  XTREG(  3, 12,32, 4, 4,0x0102,0x0006,-2, 1,0x0002,ar2,         0,0,0,0,0,0)
  XTREG(  4, 16,32, 4, 4,0x0103,0x0006,-2, 1,0x0002,ar3,         0,0,0,0,0,0)
  XTREG(  5, 20,32, 4, 4,0x0104,0x0006,-2, 1,0x0002,ar4,         0,0,0,0,0,0)
  XTREG(  6, 24,32, 4, 4,0x0105,0x0006,-2, 1,0x0002,ar5,         0,0,0,0,0,0)
  XTREG(  7, 28,32, 4, 4,0x0106,0x0006,-2, 1,0x0002,ar6,         0,0,0,0,0,0)
  XTREG(  8, 32,32, 4, 4,0x0107,0x0006,-2, 1,0x0002,ar7,         0,0,0,0,0,0)
  XTREG(  9, 36,32, 4, 4,0x0108,0x0006,-2, 1,0x0002,ar8,         0,0,0,0,0,0)
  XTREG( 10, 40,32, 4, 4,0x0109,0x0006,-2, 1,0x0002,ar9,         0,0,0,0,0,0)
  XTREG( 11, 44,32, 4, 4,0x010a,0x0006,-2, 1,0x0002,ar10,        0,0,0,0,0,0)
  XTREG( 12, 48,32, 4, 4,0x010b,0x0006,-2, 1,0x0002,ar11,        0,0,0,0,0,0)
  XTREG( 13, 52,32, 4, 4,0x010c,0x0006,-2, 1,0x0002,ar12,        0,0,0,0,0,0)
  XTREG( 14, 56,32, 4, 4,0x010d,0x0006,-2, 1,0x0002,ar13,        0,0,0,0,0,0)
  XTREG( 15, 60,32, 4, 4,0x010e,0x0006,-2, 1,0x0002,ar14,        0,0,0,0,0,0)
  XTREG( 16, 64,32, 4, 4,0x010f,0x0006,-2, 1,0x0002,ar15,        0,0,0,0,0,0)
  XTREG( 17, 68,32, 4, 4,0x0110,0x0006,-2, 1,0x0002,ar16,        0,0,0,0,0,0)
  XTREG( 18, 72,32, 4, 4,0x0111,0x0006,-2, 1,0x0002,ar17,        0,0,0,0,0,0)
  XTREG( 19, 76,32, 4, 4,0x0112,0x0006,-2, 1,0x0002,ar18,        0,0,0,0,0,0)
  XTREG( 20, 80,32, 4, 4,0x0113,0x0006,-2, 1,0x0002,ar19,        0,0,0,0,0,0)
  XTREG( 21, 84,32, 4, 4,0x0114,0x0006,-2, 1,0x0002,ar20,        0,0,0,0,0,0)
  XTREG( 22, 88,32, 4, 4,0x0115,0x0006,-2, 1,0x0002,ar21,        0,0,0,0,0,0)
  XTREG( 23, 92,32, 4, 4,0x0116,0x0006,-2, 1,0x0002,ar22,        0,0,0,0,0,0)
  XTREG( 24, 96,32, 4, 4,0x0117,0x0006,-2, 1,0x0002,ar23,        0,0,0,0,0,0)
  XTREG( 25,100,32, 4, 4,0x0118,0x0006,-2, 1,0x0002,ar24,        0,0,0,0,0,0)
  XTREG( 26,104,32, 4, 4,0x0119,0x0006,-2, 1,0x0002,ar25,        0,0,0,0,0,0)
  XTREG( 27,108,32, 4, 4,0x011a,0x0006,-2, 1,0x0002,ar26,        0,0,0,0,0,0)
  XTREG( 28,112,32, 4, 4,0x011b,0x0006,-2, 1,0x0002,ar27,        0,0,0,0,0,0)
  XTREG( 29,116,32, 4, 4,0x011c,0x0006,-2, 1,0x0002,ar28,        0,0,0,0,0,0)
  XTREG( 30,120,32, 4, 4,0x011d,0x0006,-2, 1,0x0002,ar29,        0,0,0,0,0,0)
  XTREG( 31,124,32, 4, 4,0x011e,0x0006,-2, 1,0x0002,ar30,        0,0,0,0,0,0)
  XTREG( 32,128,32, 4, 4,0x011f,0x0006,-2, 1,0x0002,ar31,        0,0,0,0,0,0)
  XTREG( 33,132,32, 4, 4,0x0200,0x0006,-2, 2,0x1100,lbeg,        0,0,0,0,0,0)
  XTREG( 34,136,32, 4, 4,0x0201,0x0006,-2, 2,0x1100,lend,        0,0,0,0,0,0)
  XTREG( 35,140,32, 4, 4,0x0202,0x0006,-2, 2,0x1100,lcount,      0,0,0,0,0,0)
  XTREG( 36,144, 6, 4, 4,0x0203,0x0006,-2, 2,0x1100,sar,         0,0,0,0,0,0)
  XTREG( 37,148,32, 4, 4,0x0205,0x0006,-2, 2,0x1100,litbase,     0,0,0,0,0,0)
  XTREG( 38,152, 3, 4, 4,0x0248,0x0006,-2, 2,0x1002,windowbase,  0,0,0,0,0,0)
  XTREG( 39,156, 8, 4, 4,0x0249,0x0006,-2, 2,0x1002,windowstart, 0,0,0,0,0,0)
  XTREG( 40,160,32, 4, 4,0x02b0,0x0002,-2, 2,0x1000,sr176,       0,0,0,0,0,0)
  XTREG( 41,164,32, 4, 4,0x02d0,0x0002,-2, 2,0x1000,sr208,       0,0,0,0,0,0)
  XTREG( 42,168,19, 4, 4,0x02e6,0x0006,-2, 2,0x1100,ps,          0,0,0,0,0,0)
  XTREG( 43,172,32, 4, 4,0x03e7,0x0006,-2, 3,0x0110,threadptr,   0,0,0,0,0,0)
  XTREG( 44,176,16, 4, 4,0x0204,0x0006,-1, 2,0x1100,br,          0,0,0,0,0,0)
  XTREG( 45,180,32, 4, 4,0x020c,0x0006,-1, 2,0x1100,scompare1,   0,0,0,0,0,0)
  XTREG( 46,184,32, 4, 4,0x0300,0x000e,-1, 3,0x0210,expstate,    0,0,0,0,0,0)
  XTREG( 47,188,32, 4, 4,0x0030,0x0006, 0, 4,0x0401,f0,
            "03:03:44:00","03:03:04:00",0,0,0,0)
  XTREG( 48,192,32, 4, 4,0x0031,0x0006, 0, 4,0x0401,f1,
            "03:13:44:00","03:13:04:00",0,0,0,0)
  XTREG( 49,196,32, 4, 4,0x0032,0x0006, 0, 4,0x0401,f2,
            "03:23:44:00","03:23:04:00",0,0,0,0)
  XTREG( 50,200,32, 4, 4,0x0033,0x0006, 0, 4,0x0401,f3,
            "03:33:44:00","03:33:04:00",0,0,0,0)
  XTREG( 51,204,32, 4, 4,0x0034,0x0006, 0, 4,0x0401,f4,
            "03:43:44:00","03:43:04:00",0,0,0,0)
  XTREG( 52,208,32, 4, 4,0x0035,0x0006, 0, 4,0x0401,f5,
            "03:53:44:00","03:53:04:00",0,0,0,0)
  XTREG( 53,212,32, 4, 4,0x0036,0x0006, 0, 4,0x0401,f6,
            "03:63:44:00","03:63:04:00",0,0,0,0)
  XTREG( 54,216,32, 4, 4,0x0037,0x0006, 0, 4,0x0401,f7,
            "03:73:44:00","03:73:04:00",0,0,0,0)
  XTREG( 55,220,32, 4, 4,0x0038,0x0006, 0, 4,0x0401,f8,
            "03:83:44:00","03:83:04:00",0,0,0,0)
  XTREG( 56,224,32, 4, 4,0x0039,0x0006, 0, 4,0x0401,f9,
            "03:93:44:00","03:93:04:00",0,0,0,0)
  XTREG( 57,228,32, 4, 4,0x003a,0x0006, 0, 4,0x0401,f10,
            "03:a3:44:00","03:a3:04:00",0,0,0,0)
  XTREG( 58,232,32, 4, 4,0x003b,0x0006, 0, 4,0x0401,f11,
            "03:b3:44:00","03:b3:04:00",0,0,0,0)
  XTREG( 59,236,32, 4, 4,0x003c,0x0006, 0, 4,0x0401,f12,
            "03:c3:44:00","03:c3:04:00",0,0,0,0)
  XTREG( 60,240,32, 4, 4,0x003d,0x0006, 0, 4,0x0401,f13,
            "03:d3:44:00","03:d3:04:00",0,0,0,0)
  XTREG( 61,244,32, 4, 4,0x003e,0x0006, 0, 4,0x0401,f14,
            "03:e3:44:00","03:e3:04:00",0,0,0,0)
  XTREG( 62,248,32, 4, 4,0x003f,0x0006, 0, 4,0x0401,f15,
            "03:f3:44:00","03:f3:04:00",0,0,0,0)
  XTREG( 63,252,32, 4, 4,0x03e8,0x0006, 0, 3,0x0100,fcr,         0,0,0,0,0,0)
  XTREG( 64,256,32, 4, 4,0x03e9,0x0006, 0, 3,0x0100,fsr,         0,0,0,0,0,0)
  XTREG( 65,260, 4, 4, 4,0x0301,0x0006, 2, 3,0x0210,sov,         0,0,0,0,0,0)
  XTREG( 66,264, 1, 4, 4,0x0302,0x0006, 2, 3,0x0210,sat_mode,    0,0,0,0,0,0)
  XTREG( 67,268, 6, 4, 4,0x0303,0x0006, 2, 3,0x0210,sar0,        0,0,0,0,0,0)
  XTREG( 68,272, 6, 4, 4,0x0304,0x0006, 2, 3,0x0210,sar1,        0,0,0,0,0,0)
  XTREG( 69,276, 6, 4, 4,0x0305,0x0006, 2, 3,0x0210,sar2,        0,0,0,0,0,0)
  XTREG( 70,280, 6, 4, 4,0x0306,0x0006, 2, 3,0x0210,sar3,        0,0,0,0,0,0)
  XTREG( 71,284, 6, 4, 4,0x0307,0x0006, 2, 3,0x0210,hsar0,       0,0,0,0,0,0)
  XTREG( 72,288, 6, 4, 4,0x0308,0x0006, 2, 3,0x0210,hsar1,       0,0,0,0,0,0)
  XTREG( 73,292, 6, 4, 4,0x0309,0x0006, 2, 3,0x0210,hsar2,       0,0,0,0,0,0)
  XTREG( 74,296, 6, 4, 4,0x030a,0x0006, 2, 3,0x0210,hsar3,       0,0,0,0,0,0)
  XTREG( 75,300,32, 4, 4,0x030b,0x0006, 2, 3,0x0200,max_reg_0,   0,0,0,0,0,0)
  XTREG( 76,304,32, 4, 4,0x030c,0x0006, 2, 3,0x0200,max_reg_1,   0,0,0,0,0,0)
  XTREG( 77,308,32, 4, 4,0x030d,0x0006, 2, 3,0x0200,max_reg_2,   0,0,0,0,0,0)
  XTREG( 78,312,32, 4, 4,0x030e,0x0006, 2, 3,0x0200,max_reg_3,   0,0,0,0,0,0)
  XTREG( 79,316,32, 4, 4,0x030f,0x0006, 2, 3,0x0200,arg_max_reg_0,0,0,0,0,0,0)
  XTREG( 80,320,32, 4, 4,0x0310,0x0006, 2, 3,0x0200,arg_max_reg_1,0,0,0,0,0,0)
  XTREG( 81,324,32, 4, 4,0x0311,0x0006, 2, 3,0x0200,arg_max_reg_2,0,0,0,0,0,0)
  XTREG( 82,328,32, 4, 4,0x0312,0x0006, 2, 3,0x0200,arg_max_reg_3,0,0,0,0,0,0)
  XTREG( 83,332,32, 4, 4,0x0313,0x0006, 2, 3,0x0200,nco_counter_0,0,0,0,0,0,0)
  XTREG( 84,336,32, 4, 4,0x0314,0x0006, 2, 3,0x0200,nco_counter_1,0,0,0,0,0,0)
  XTREG( 85,340,32, 4, 4,0x0315,0x0006, 2, 3,0x0200,nco_counter_2,0,0,0,0,0,0)
  XTREG( 86,344,32, 4, 4,0x0316,0x0006, 2, 3,0x0200,nco_counter_3,0,0,0,0,0,0)
  XTREG( 87,348, 4, 4, 4,0x0317,0x0006, 2, 3,0x0210,interp_ext_n,0,0,0,0,0,0)
  XTREG( 88,352, 4, 4, 4,0x0318,0x0006, 2, 3,0x0210,interp_ext_l,0,0,0,0,0,0)
  XTREG( 89,356,32, 4, 4,0x0319,0x0006, 2, 3,0x0200,llr_buf_0,   0,0,0,0,0,0)
  XTREG( 90,360,32, 4, 4,0x031a,0x0006, 2, 3,0x0200,llr_buf_1,   0,0,0,0,0,0)
  XTREG( 91,364,32, 4, 4,0x031b,0x0006, 2, 3,0x0200,llr_buf_2,   0,0,0,0,0,0)
  XTREG( 92,368,32, 4, 4,0x031c,0x0006, 2, 3,0x0200,llr_buf_3,   0,0,0,0,0,0)
  XTREG( 93,372,32, 4, 4,0x031d,0x0006, 2, 3,0x0200,llr_buf_4,   0,0,0,0,0,0)
  XTREG( 94,376,32, 4, 4,0x031e,0x0006, 2, 3,0x0200,llr_buf_5,   0,0,0,0,0,0)
  XTREG( 95,380,32, 4, 4,0x031f,0x0006, 2, 3,0x0200,llr_buf_6,   0,0,0,0,0,0)
  XTREG( 96,384,32, 4, 4,0x0320,0x0006, 2, 3,0x0200,llr_buf_7,   0,0,0,0,0,0)
  XTREG( 97,388,32, 4, 4,0x0321,0x0006, 2, 3,0x0200,llr_buf_8,   0,0,0,0,0,0)
  XTREG( 98,392,32, 4, 4,0x0322,0x0006, 2, 3,0x0200,llr_buf_9,   0,0,0,0,0,0)
  XTREG( 99,396,32, 4, 4,0x0323,0x0006, 2, 3,0x0200,llr_buf_10,  0,0,0,0,0,0)
  XTREG(100,400,32, 4, 4,0x0324,0x0006, 2, 3,0x0200,llr_buf_11,  0,0,0,0,0,0)
  XTREG(101,404,32, 4, 4,0x0325,0x0006, 2, 3,0x0200,llr_buf_12,  0,0,0,0,0,0)
  XTREG(102,408,32, 4, 4,0x0326,0x0006, 2, 3,0x0200,llr_buf_13,  0,0,0,0,0,0)
  XTREG(103,412,32, 4, 4,0x0327,0x0006, 2, 3,0x0200,llr_buf_14,  0,0,0,0,0,0)
  XTREG(104,416,32, 4, 4,0x0328,0x0006, 2, 3,0x0200,llr_buf_15,  0,0,0,0,0,0)
  XTREG(105,420,32, 4, 4,0x0329,0x0006, 2, 3,0x0200,llr_buf_16,  0,0,0,0,0,0)
  XTREG(106,424,32, 4, 4,0x032a,0x0006, 2, 3,0x0200,llr_buf_17,  0,0,0,0,0,0)
  XTREG(107,428,32, 4, 4,0x032b,0x0006, 2, 3,0x0200,llr_buf_18,  0,0,0,0,0,0)
  XTREG(108,432,32, 4, 4,0x032c,0x0006, 2, 3,0x0200,llr_buf_19,  0,0,0,0,0,0)
  XTREG(109,436,32, 4, 4,0x032d,0x0006, 2, 3,0x0200,llr_buf_20,  0,0,0,0,0,0)
  XTREG(110,440,32, 4, 4,0x032e,0x0006, 2, 3,0x0200,llr_buf_21,  0,0,0,0,0,0)
  XTREG(111,444,32, 4, 4,0x032f,0x0006, 2, 3,0x0200,llr_buf_22,  0,0,0,0,0,0)
  XTREG(112,448,32, 4, 4,0x0330,0x0006, 2, 3,0x0200,llr_buf_23,  0,0,0,0,0,0)
  XTREG(113,452,32, 4, 4,0x0331,0x0006, 2, 3,0x0200,smod_buf_0,  0,0,0,0,0,0)
  XTREG(114,456,32, 4, 4,0x0332,0x0006, 2, 3,0x0200,smod_buf_1,  0,0,0,0,0,0)
  XTREG(115,460,32, 4, 4,0x0333,0x0006, 2, 3,0x0200,smod_buf_2,  0,0,0,0,0,0)
  XTREG(116,464,32, 4, 4,0x0334,0x0006, 2, 3,0x0200,smod_buf_3,  0,0,0,0,0,0)
  XTREG(117,468,32, 4, 4,0x0335,0x0006, 2, 3,0x0200,smod_buf_4,  0,0,0,0,0,0)
  XTREG(118,472,32, 4, 4,0x0336,0x0006, 2, 3,0x0200,smod_buf_5,  0,0,0,0,0,0)
  XTREG(119,476,32, 4, 4,0x0337,0x0006, 2, 3,0x0200,smod_buf_6,  0,0,0,0,0,0)
  XTREG(120,480,32, 4, 4,0x0338,0x0006, 2, 3,0x0200,smod_buf_7,  0,0,0,0,0,0)
  XTREG(121,484, 8, 4, 4,0x0339,0x0006, 2, 3,0x0210,weight_reg,  0,0,0,0,0,0)
  XTREG(122,488, 5, 4, 4,0x033a,0x0006, 2, 3,0x0210,scale_reg,   0,0,0,0,0,0)
  XTREG(123,492, 6, 4, 4,0x033b,0x0006, 2, 3,0x0210,llr_pos,     0,0,0,0,0,0)
  XTREG(124,496, 7, 4, 4,0x033c,0x0006, 2, 3,0x0210,smod_pos,    0,0,0,0,0,0)
  XTREG(125,500,32, 4, 4,0x033d,0x0006, 2, 3,0x0210,perm_reg,    0,0,0,0,0,0)
  XTREG(126,504,32, 4, 4,0x033e,0x0006, 2, 3,0x0200,smod_offset_table_0,0,0,0,0,0,0)
  XTREG(127,508,32, 4, 4,0x033f,0x0006, 2, 3,0x0200,smod_offset_table_1,0,0,0,0,0,0)
  XTREG(128,512,32, 4, 4,0x0340,0x0006, 2, 3,0x0200,smod_offset_table_2,0,0,0,0,0,0)
  XTREG(129,516,32, 4, 4,0x0341,0x0006, 2, 3,0x0200,smod_offset_table_3,0,0,0,0,0,0)
  XTREG(130,520, 4, 4, 4,0x0342,0x0006, 2, 3,0x0210,phasor_n,    0,0,0,0,0,0)
  XTREG(131,524,16, 4, 4,0x0343,0x0006, 2, 3,0x0210,phasor_offset,0,0,0,0,0,0)
  XTREG(132,528,320,64,16,0x1008,0x0006, 2, 4,0x0201,acu0,
            "03:00:84:f8:03:10:84:8d:03:20:84:9d:03:30:84:ac","03:43:20:08:03:43:28:03:03:43:20:33:03:43:28:25",0,0,0,0)
  XTREG(133,592,320,64,16,0x1009,0x0006, 2, 4,0x0201,acu1,
            "03:00:94:f8:03:10:94:8d:03:20:94:9d:03:30:94:ac","03:43:21:08:03:43:29:03:03:43:21:33:03:43:29:25",0,0,0,0)
  XTREG(134,656,320,64,16,0x100a,0x0006, 2, 4,0x0201,acu2,
            "03:00:a4:f8:03:10:a4:8d:03:20:a4:9d:03:30:a4:ac","03:43:22:08:03:43:2a:03:03:43:22:33:03:43:2a:25",0,0,0,0)
  XTREG(135,720,320,64,16,0x100b,0x0006, 2, 4,0x0201,acu3,
            "03:00:b4:f8:03:10:b4:8d:03:20:b4:9d:03:30:b4:ac","03:43:23:08:03:43:2b:03:03:43:23:33:03:43:2b:25",0,0,0,0)
  XTREG(136,784,320,64,16,0x100c,0x0006, 2, 4,0x0201,acu4,
            "03:00:c4:f8:03:10:c4:8d:03:20:c4:9d:03:30:c4:ac","03:43:24:08:03:43:2c:03:03:43:24:33:03:43:2c:25",0,0,0,0)
  XTREG(137,848,320,64,16,0x100d,0x0006, 2, 4,0x0201,acu5,
            "03:00:d4:f8:03:10:d4:8d:03:20:d4:9d:03:30:d4:ac","03:43:25:08:03:43:2d:03:03:43:25:33:03:43:2d:25",0,0,0,0)
  XTREG(138,912,320,64,16,0x100e,0x0006, 2, 4,0x0201,acu6,
            "03:00:e4:f8:03:10:e4:8d:03:20:e4:9d:03:30:e4:ac","03:43:26:08:03:43:2e:03:03:43:26:33:03:43:2e:25",0,0,0,0)
  XTREG(139,976,320,64,16,0x100f,0x0006, 2, 4,0x0201,acu7,
            "03:00:f4:f8:03:10:f4:8d:03:20:f4:9d:03:30:f4:ac","03:43:27:08:03:43:2f:03:03:43:27:33:03:43:2f:25",0,0,0,0)
  XTREG(140,1040,128,16,16,0x1010,0x0006, 2, 4,0x0201,cm0,
            "03:00:04:5d","03:40:03:07",0,0,0,0)
  XTREG(141,1056,128,16,16,0x1011,0x0006, 2, 4,0x0201,cm1,
            "03:00:14:5d","03:40:13:07",0,0,0,0)
  XTREG(142,1072,128,16,16,0x1012,0x0006, 2, 4,0x0201,cm2,
            "03:00:24:5d","03:40:23:07",0,0,0,0)
  XTREG(143,1088,128,16,16,0x1013,0x0006, 2, 4,0x0201,cm3,
            "03:00:34:5d","03:40:33:07",0,0,0,0)
  XTREG(144,1104,128,16,16,0x1014,0x0006, 2, 4,0x0201,cm4,
            "03:00:44:5d","03:40:43:07",0,0,0,0)
  XTREG(145,1120,128,16,16,0x1015,0x0006, 2, 4,0x0201,cm5,
            "03:00:54:5d","03:40:53:07",0,0,0,0)
  XTREG(146,1136,128,16,16,0x1016,0x0006, 2, 4,0x0201,cm6,
            "03:00:64:5d","03:40:63:07",0,0,0,0)
  XTREG(147,1152,128,16,16,0x1017,0x0006, 2, 4,0x0201,cm7,
            "03:00:74:5d","03:40:73:07",0,0,0,0)
  XTREG(148,1168,128,16,16,0x1018,0x0006, 2, 4,0x0201,cm8,
            "03:00:84:5d","03:40:83:07",0,0,0,0)
  XTREG(149,1184,128,16,16,0x1019,0x0006, 2, 4,0x0201,cm9,
            "03:00:94:5d","03:40:93:07",0,0,0,0)
  XTREG(150,1200,128,16,16,0x101a,0x0006, 2, 4,0x0201,cm10,
            "03:00:a4:5d","03:40:a3:07",0,0,0,0)
  XTREG(151,1216,128,16,16,0x101b,0x0006, 2, 4,0x0201,cm11,
            "03:00:b4:5d","03:40:b3:07",0,0,0,0)
  XTREG(152,1232,128,16,16,0x101c,0x0006, 2, 4,0x0201,cm12,
            "03:00:c4:5d","03:40:c3:07",0,0,0,0)
  XTREG(153,1248,128,16,16,0x101d,0x0006, 2, 4,0x0201,cm13,
            "03:00:d4:5d","03:40:d3:07",0,0,0,0)
  XTREG(154,1264,128,16,16,0x101e,0x0006, 2, 4,0x0201,cm14,
            "03:00:e4:5d","03:40:e3:07",0,0,0,0)
  XTREG(155,1280,128,16,16,0x101f,0x0006, 2, 4,0x0201,cm15,
            "03:00:f4:5d","03:40:f3:07",0,0,0,0)
  XTREG(156,1296,256,32,16,0x1020,0x0006, 2, 4,0x0201,pq0,
            "03:00:04:7c:03:10:04:cc","03:40:02:07:03:40:0c:07",0,0,0,0)
  XTREG(157,1328,256,32,16,0x1021,0x0006, 2, 4,0x0201,pq1,
            "03:00:14:7c:03:10:14:cc","03:40:12:07:03:40:1c:07",0,0,0,0)
  XTREG(158,1360,256,32,16,0x1022,0x0006, 2, 4,0x0201,pq2,
            "03:00:24:7c:03:10:24:cc","03:40:22:07:03:40:2c:07",0,0,0,0)
  XTREG(159,1392,256,32,16,0x1023,0x0006, 2, 4,0x0201,pq3,
            "03:00:34:7c:03:10:34:cc","03:40:32:07:03:40:3c:07",0,0,0,0)
  XTREG(160,1424,256,32,16,0x1024,0x0006, 2, 4,0x0201,pq4,
            "03:00:44:7c:03:10:44:cc","03:40:42:07:03:40:4c:07",0,0,0,0)
  XTREG(161,1456,256,32,16,0x1025,0x0006, 2, 4,0x0201,pq5,
            "03:00:54:7c:03:10:54:cc","03:40:52:07:03:40:5c:07",0,0,0,0)
  XTREG(162,1488,256,32,16,0x1026,0x0006, 2, 4,0x0201,pq6,
            "03:00:64:7c:03:10:64:cc","03:40:62:07:03:40:6c:07",0,0,0,0)
  XTREG(163,1520,256,32,16,0x1027,0x0006, 2, 4,0x0201,pq7,
            "03:00:74:7c:03:10:74:cc","03:40:72:07:03:40:7c:07",0,0,0,0)
  XTREG(164,1552,256,32,16,0x1028,0x0006, 2, 4,0x0201,pq8,
            "03:00:84:7c:03:10:84:cc","03:40:82:07:03:40:8c:07",0,0,0,0)
  XTREG(165,1584,256,32,16,0x1029,0x0006, 2, 4,0x0201,pq9,
            "03:00:94:7c:03:10:94:cc","03:40:92:07:03:40:9c:07",0,0,0,0)
  XTREG(166,1616,256,32,16,0x102a,0x0006, 2, 4,0x0201,pq10,
            "03:00:a4:7c:03:10:a4:cc","03:40:a2:07:03:40:ac:07",0,0,0,0)
  XTREG(167,1648,256,32,16,0x102b,0x0006, 2, 4,0x0201,pq11,
            "03:00:b4:7c:03:10:b4:cc","03:40:b2:07:03:40:bc:07",0,0,0,0)
  XTREG(168,1680,256,32,16,0x102c,0x0006, 2, 4,0x0201,pq12,
            "03:00:c4:7c:03:10:c4:cc","03:40:c2:07:03:40:cc:07",0,0,0,0)
  XTREG(169,1712,256,32,16,0x102d,0x0006, 2, 4,0x0201,pq13,
            "03:00:d4:7c:03:10:d4:cc","03:40:d2:07:03:40:dc:07",0,0,0,0)
  XTREG(170,1744,256,32,16,0x102e,0x0006, 2, 4,0x0201,pq14,
            "03:00:e4:7c:03:10:e4:cc","03:40:e2:07:03:40:ec:07",0,0,0,0)
  XTREG(171,1776,256,32,16,0x102f,0x0006, 2, 4,0x0201,pq15,
            "03:00:f4:7c:03:10:f4:cc","03:40:f2:07:03:40:fc:07",0,0,0,0)
  XTREG(172,1808,32, 4, 4,0x0259,0x000d,-2, 2,0x1000,mmid,        0,0,0,0,0,0)
  XTREG(173,1812, 2, 4, 4,0x0260,0x0007,-2, 2,0x1000,ibreakenable,0,0,0,0,0,0)
  XTREG(174,1816, 6, 4, 4,0x0263,0x0007,-2, 2,0x1000,atomctl,     0,0,0,0,0,0)
  XTREG(175,1820,32, 4, 4,0x0268,0x0007,-2, 2,0x1000,ddr,         0,0,0,0,0,0)
  XTREG(176,1824,32, 4, 4,0x0280,0x0007,-2, 2,0x1000,ibreaka0,    0,0,0,0,0,0)
  XTREG(177,1828,32, 4, 4,0x0281,0x0007,-2, 2,0x1000,ibreaka1,    0,0,0,0,0,0)
  XTREG(178,1832,32, 4, 4,0x0290,0x0007,-2, 2,0x1000,dbreaka0,    0,0,0,0,0,0)
  XTREG(179,1836,32, 4, 4,0x0291,0x0007,-2, 2,0x1000,dbreaka1,    0,0,0,0,0,0)
  XTREG(180,1840,32, 4, 4,0x02a0,0x0007,-2, 2,0x1000,dbreakc0,    0,0,0,0,0,0)
  XTREG(181,1844,32, 4, 4,0x02a1,0x0007,-2, 2,0x1000,dbreakc1,    0,0,0,0,0,0)
  XTREG(182,1848,32, 4, 4,0x02b1,0x0007,-2, 2,0x1000,epc1,        0,0,0,0,0,0)
  XTREG(183,1852,32, 4, 4,0x02b2,0x0007,-2, 2,0x1000,epc2,        0,0,0,0,0,0)
  XTREG(184,1856,32, 4, 4,0x02b3,0x0007,-2, 2,0x1000,epc3,        0,0,0,0,0,0)
  XTREG(185,1860,32, 4, 4,0x02b4,0x0007,-2, 2,0x1000,epc4,        0,0,0,0,0,0)
  XTREG(186,1864,32, 4, 4,0x02b5,0x0007,-2, 2,0x1000,epc5,        0,0,0,0,0,0)
  XTREG(187,1868,32, 4, 4,0x02b6,0x0007,-2, 2,0x1000,epc6,        0,0,0,0,0,0)
  XTREG(188,1872,32, 4, 4,0x02c0,0x0007,-2, 2,0x1000,depc,        0,0,0,0,0,0)
  XTREG(189,1876,19, 4, 4,0x02c2,0x0007,-2, 2,0x1000,eps2,        0,0,0,0,0,0)
  XTREG(190,1880,19, 4, 4,0x02c3,0x0007,-2, 2,0x1000,eps3,        0,0,0,0,0,0)
  XTREG(191,1884,19, 4, 4,0x02c4,0x0007,-2, 2,0x1000,eps4,        0,0,0,0,0,0)
  XTREG(192,1888,19, 4, 4,0x02c5,0x0007,-2, 2,0x1000,eps5,        0,0,0,0,0,0)
  XTREG(193,1892,19, 4, 4,0x02c6,0x0007,-2, 2,0x1000,eps6,        0,0,0,0,0,0)
  XTREG(194,1896,32, 4, 4,0x02d1,0x0007,-2, 2,0x1000,excsave1,    0,0,0,0,0,0)
  XTREG(195,1900,32, 4, 4,0x02d2,0x0007,-2, 2,0x1000,excsave2,    0,0,0,0,0,0)
  XTREG(196,1904,32, 4, 4,0x02d3,0x0007,-2, 2,0x1000,excsave3,    0,0,0,0,0,0)
  XTREG(197,1908,32, 4, 4,0x02d4,0x0007,-2, 2,0x1000,excsave4,    0,0,0,0,0,0)
  XTREG(198,1912,32, 4, 4,0x02d5,0x0007,-2, 2,0x1000,excsave5,    0,0,0,0,0,0)
  XTREG(199,1916,32, 4, 4,0x02d6,0x0007,-2, 2,0x1000,excsave6,    0,0,0,0,0,0)
  XTREG(200,1920, 4, 4, 4,0x02e0,0x0007,-2, 2,0x1000,cpenable,    0,0,0,0,0,0)
  XTREG(201,1924,13, 4, 4,0x02e2,0x000b,-2, 2,0x1000,interrupt,   0,0,0,0,0,0)
  XTREG(202,1928,13, 4, 4,0x02e2,0x000d,-2, 2,0x1000,intset,      0,0,0,0,0,0)
  XTREG(203,1932,13, 4, 4,0x02e3,0x000d,-2, 2,0x1000,intclear,    0,0,0,0,0,0)
  XTREG(204,1936,13, 4, 4,0x02e4,0x0007,-2, 2,0x1000,intenable,   0,0,0,0,0,0)
  XTREG(205,1940,32, 4, 4,0x02e7,0x0007,-2, 2,0x1000,vecbase,     0,0,0,0,0,0)
  XTREG(206,1944, 6, 4, 4,0x02e8,0x0007,-2, 2,0x1000,exccause,    0,0,0,0,0,0)
  XTREG(207,1948,12, 4, 4,0x02e9,0x0003,-2, 2,0x1000,debugcause,  0,0,0,0,0,0)
  XTREG(208,1952,32, 4, 4,0x02ea,0x000f,-2, 2,0x1000,ccount,      0,0,0,0,0,0)
  XTREG(209,1956,32, 4, 4,0x02eb,0x0003,-2, 2,0x1000,prid,        0,0,0,0,0,0)
  XTREG(210,1960,32, 4, 4,0x02ec,0x000f,-2, 2,0x1000,icount,      0,0,0,0,0,0)
  XTREG(211,1964, 4, 4, 4,0x02ed,0x0007,-2, 2,0x1000,icountlevel, 0,0,0,0,0,0)
  XTREG(212,1968,32, 4, 4,0x02ee,0x0007,-2, 2,0x1000,excvaddr,    0,0,0,0,0,0)
  XTREG(213,1972,32, 4, 4,0x02f0,0x000f,-2, 2,0x1000,ccompare0,   0,0,0,0,0,0)
  XTREG(214,1976,32, 4, 4,0x02f1,0x000f,-2, 2,0x1000,ccompare1,   0,0,0,0,0,0)
  XTREG(215,1980,32, 4, 4,0x0000,0x0006,-2, 8,0x0100,a0,          0,0,0,0,0,0)
  XTREG(216,1984,32, 4, 4,0x0001,0x0006,-2, 8,0x0100,a1,          0,0,0,0,0,0)
  XTREG(217,1988,32, 4, 4,0x0002,0x0006,-2, 8,0x0100,a2,          0,0,0,0,0,0)
  XTREG(218,1992,32, 4, 4,0x0003,0x0006,-2, 8,0x0100,a3,          0,0,0,0,0,0)
  XTREG(219,1996,32, 4, 4,0x0004,0x0006,-2, 8,0x0100,a4,          0,0,0,0,0,0)
  XTREG(220,2000,32, 4, 4,0x0005,0x0006,-2, 8,0x0100,a5,          0,0,0,0,0,0)
  XTREG(221,2004,32, 4, 4,0x0006,0x0006,-2, 8,0x0100,a6,          0,0,0,0,0,0)
  XTREG(222,2008,32, 4, 4,0x0007,0x0006,-2, 8,0x0100,a7,          0,0,0,0,0,0)
  XTREG(223,2012,32, 4, 4,0x0008,0x0006,-2, 8,0x0100,a8,          0,0,0,0,0,0)
  XTREG(224,2016,32, 4, 4,0x0009,0x0006,-2, 8,0x0100,a9,          0,0,0,0,0,0)
  XTREG(225,2020,32, 4, 4,0x000a,0x0006,-2, 8,0x0100,a10,         0,0,0,0,0,0)
  XTREG(226,2024,32, 4, 4,0x000b,0x0006,-2, 8,0x0100,a11,         0,0,0,0,0,0)
  XTREG(227,2028,32, 4, 4,0x000c,0x0006,-2, 8,0x0100,a12,         0,0,0,0,0,0)
  XTREG(228,2032,32, 4, 4,0x000d,0x0006,-2, 8,0x0100,a13,         0,0,0,0,0,0)
  XTREG(229,2036,32, 4, 4,0x000e,0x0006,-2, 8,0x0100,a14,         0,0,0,0,0,0)
  XTREG(230,2040,32, 4, 4,0x000f,0x0006,-2, 8,0x0100,a15,         0,0,0,0,0,0)
  XTREG(231,2044, 1, 1, 1,0x0010,0x0006,-2, 6,0x1010,b0,
            0,0,&xtensa_mask0,0,0,0)
  XTREG(232,2045, 1, 1, 1,0x0011,0x0006,-2, 6,0x1010,b1,
            0,0,&xtensa_mask1,0,0,0)
  XTREG(233,2046, 1, 1, 1,0x0012,0x0006,-2, 6,0x1010,b2,
            0,0,&xtensa_mask2,0,0,0)
  XTREG(234,2047, 1, 1, 1,0x0013,0x0006,-2, 6,0x1010,b3,
            0,0,&xtensa_mask3,0,0,0)
  XTREG(235,2048, 1, 1, 1,0x0014,0x0006,-2, 6,0x1010,b4,
            0,0,&xtensa_mask4,0,0,0)
  XTREG(236,2049, 1, 1, 1,0x0015,0x0006,-2, 6,0x1010,b5,
            0,0,&xtensa_mask5,0,0,0)
  XTREG(237,2050, 1, 1, 1,0x0016,0x0006,-2, 6,0x1010,b6,
            0,0,&xtensa_mask6,0,0,0)
  XTREG(238,2051, 1, 1, 1,0x0017,0x0006,-2, 6,0x1010,b7,
            0,0,&xtensa_mask7,0,0,0)
  XTREG(239,2052, 1, 1, 1,0x0018,0x0006,-2, 6,0x1010,b8,
            0,0,&xtensa_mask8,0,0,0)
  XTREG(240,2053, 1, 1, 1,0x0019,0x0006,-2, 6,0x1010,b9,
            0,0,&xtensa_mask9,0,0,0)
  XTREG(241,2054, 1, 1, 1,0x001a,0x0006,-2, 6,0x1010,b10,
            0,0,&xtensa_mask10,0,0,0)
  XTREG(242,2055, 1, 1, 1,0x001b,0x0006,-2, 6,0x1010,b11,
            0,0,&xtensa_mask11,0,0,0)
  XTREG(243,2056, 1, 1, 1,0x001c,0x0006,-2, 6,0x1010,b12,
            0,0,&xtensa_mask12,0,0,0)
  XTREG(244,2057, 1, 1, 1,0x001d,0x0006,-2, 6,0x1010,b13,
            0,0,&xtensa_mask13,0,0,0)
  XTREG(245,2058, 1, 1, 1,0x001e,0x0006,-2, 6,0x1010,b14,
            0,0,&xtensa_mask14,0,0,0)
  XTREG(246,2059, 1, 1, 1,0x001f,0x0006,-2, 6,0x1010,b15,
            0,0,&xtensa_mask15,0,0,0)
  XTREG(247,2060, 4, 4, 4,0x2007,0x0006,-2, 6,0x1010,psintlevel,
            0,0,&xtensa_mask16,0,0,0)
  XTREG(248,2064, 1, 4, 4,0x2008,0x0006,-2, 6,0x1010,psum,
            0,0,&xtensa_mask17,0,0,0)
  XTREG(249,2068, 1, 4, 4,0x2009,0x0006,-2, 6,0x1010,pswoe,
            0,0,&xtensa_mask18,0,0,0)
  XTREG(250,2072, 1, 4, 4,0x200a,0x0006,-2, 6,0x1010,psexcm,
            0,0,&xtensa_mask19,0,0,0)
  XTREG(251,2076, 2, 4, 4,0x200b,0x0006,-2, 6,0x1010,pscallinc,
            0,0,&xtensa_mask20,0,0,0)
  XTREG(252,2080, 4, 4, 4,0x200c,0x0006,-2, 6,0x1010,psowb,
            0,0,&xtensa_mask21,0,0,0)
  XTREG(253,2084,20, 4, 4,0x200d,0x0006,-2, 6,0x1010,litbaddr,
            0,0,&xtensa_mask22,0,0,0)
  XTREG(254,2088, 1, 4, 4,0x200e,0x0006,-2, 6,0x1010,litben,
            0,0,&xtensa_mask23,0,0,0)
  XTREG(255,2092, 4, 4, 4,0x2013,0x0006,-2, 6,0x1010,dbnum,
            0,0,&xtensa_mask24,0,0,0)
  XTREG(256,2096, 2, 4, 4,0x2014,0x0006, 0, 5,0x1010,roundmode,
            0,0,&xtensa_mask25,0,0,0)
  XTREG(257,2100, 1, 4, 4,0x2015,0x0006, 0, 5,0x1010,invalidenable,
            0,0,&xtensa_mask26,0,0,0)
  XTREG(258,2104, 1, 4, 4,0x2016,0x0006, 0, 5,0x1010,divzeroenable,
            0,0,&xtensa_mask27,0,0,0)
  XTREG(259,2108, 1, 4, 4,0x2017,0x0006, 0, 5,0x1010,overflowenable,
            0,0,&xtensa_mask28,0,0,0)
  XTREG(260,2112, 1, 4, 4,0x2018,0x0006, 0, 5,0x1010,underflowenable,
            0,0,&xtensa_mask29,0,0,0)
  XTREG(261,2116, 1, 4, 4,0x2019,0x0006, 0, 5,0x1010,inexactenable,
            0,0,&xtensa_mask30,0,0,0)
  XTREG(262,2120, 1, 4, 4,0x201a,0x0006, 0, 5,0x1010,invalidflag,
            0,0,&xtensa_mask31,0,0,0)
  XTREG(263,2124, 1, 4, 4,0x201b,0x0006, 0, 5,0x1010,divzeroflag,
            0,0,&xtensa_mask32,0,0,0)
  XTREG(264,2128, 1, 4, 4,0x201c,0x0006, 0, 5,0x1010,overflowflag,
            0,0,&xtensa_mask33,0,0,0)
  XTREG(265,2132, 1, 4, 4,0x201d,0x0006, 0, 5,0x1010,underflowflag,
            0,0,&xtensa_mask34,0,0,0)
  XTREG(266,2136, 1, 4, 4,0x201e,0x0006, 0, 5,0x1010,inexactflag,
            0,0,&xtensa_mask35,0,0,0)
  XTREG(267,2140,20, 4, 4,0x201f,0x0006, 0, 5,0x1010,fpreserved20,
            0,0,&xtensa_mask36,0,0,0)
  XTREG(268,2144,20, 4, 4,0x2020,0x0006, 0, 5,0x1010,fpreserved20a,
            0,0,&xtensa_mask37,0,0,0)
  XTREG(269,2148, 5, 4, 4,0x2021,0x0006, 0, 5,0x1010,fpreserved5,
            0,0,&xtensa_mask38,0,0,0)
  XTREG(270,2152, 7, 4, 4,0x2022,0x0006, 0, 5,0x1010,fpreserved7,
            0,0,&xtensa_mask39,0,0,0)
  XTREG(271,2156,128,16, 4,0x2023,0x0006, 2, 5,0x0210,max_reg,
            0,0,&xtensa_mask40,0,0,0)
  XTREG(272,2172,128,16, 4,0x2024,0x0006, 2, 5,0x0210,arg_max_reg,
            0,0,&xtensa_mask41,0,0,0)
  XTREG(273,2188,128,16, 4,0x2025,0x0006, 2, 5,0x0210,nco_counter,
            0,0,&xtensa_mask42,0,0,0)
  XTREG(274,2204,768,96, 4,0x2026,0x0006, 2, 5,0x0210,llr_buf,
            0,0,&xtensa_mask43,0,0,0)
  XTREG(275,2300,256,32, 4,0x2027,0x0006, 2, 5,0x0210,smod_buf,
            0,0,&xtensa_mask44,0,0,0)
  XTREG_END
};



#ifdef XTENSA_CONFIG_INSTANTIATE
XTENSA_CONFIG_INSTANTIATE(rmap,64)
#endif

