/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	216

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   75, 300,   8,   8,  4, -1, 0x0204, "br" },
  {   76, 304,  12,  12,  4, -1, 0x020c, "scompare1" },
  {   77, 308,   0,   0,  4, -1, 0x0210, "acclo" },
  {   78, 312,   4,   4,  4, -1, 0x0211, "acchi" },
  {   79, 316,  16,  16,  4, -1, 0x0220, "m0" },
  {   80, 320,  20,  20,  4, -1, 0x0221, "m1" },
  {   81, 324,  24,  24,  4, -1, 0x0222, "m2" },
  {   82, 328,  28,  28,  4, -1, 0x0223, "m3" },
  {   84, 336,   0,  32,  4,  1, 0x03f0, "ae_ovf_sar" },
  {   85, 340,   4,  36,  4,  1, 0x03f1, "ae_bithead" },
  {   86, 344,   8,  40,  4,  1, 0x03f2, "ae_ts_fts_bu_bp" },
  {   87, 348,  12,  44,  4,  1, 0x03f3, "ae_cw_sd_no" },
  {   88, 352,  16,  48,  4,  1, 0x03f6, "ae_cbegin0" },
  {   89, 356,  20,  52,  4,  1, 0x03f7, "ae_cend0" },
  {   90, 360,  24,  56,  8,  1, 0x1010, "aed0" },
  {   91, 368,  32,  64,  8,  1, 0x1011, "aed1" },
  {   92, 376,  40,  72,  8,  1, 0x1012, "aed2" },
  {   93, 384,  48,  80,  8,  1, 0x1013, "aed3" },
  {   94, 392,  56,  88,  8,  1, 0x1014, "aed4" },
  {   95, 400,  64,  96,  8,  1, 0x1015, "aed5" },
  {   96, 408,  72, 104,  8,  1, 0x1016, "aed6" },
  {   97, 416,  80, 112,  8,  1, 0x1017, "aed7" },
  {   98, 424,  88, 120,  8,  1, 0x1018, "aed8" },
  {   99, 432,  96, 128,  8,  1, 0x1019, "aed9" },
  {  100, 440, 104, 136,  8,  1, 0x101a, "aed10" },
  {  101, 448, 112, 144,  8,  1, 0x101b, "aed11" },
  {  102, 456, 120, 152,  8,  1, 0x101c, "aed12" },
  {  103, 464, 128, 160,  8,  1, 0x101d, "aed13" },
  {  104, 472, 136, 168,  8,  1, 0x101e, "aed14" },
  {  105, 480, 144, 176,  8,  1, 0x101f, "aed15" },
  {  106, 488, 152, 184,  8,  1, 0x1020, "u0" },
  {  107, 496, 160, 192,  8,  1, 0x1021, "u1" },
  {  108, 504, 168, 200,  8,  1, 0x1022, "u2" },
  {  109, 512, 176, 208,  8,  1, 0x1023, "u3" },
  { 0 }
};

