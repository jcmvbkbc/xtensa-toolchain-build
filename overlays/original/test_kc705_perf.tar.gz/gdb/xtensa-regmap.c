/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	216

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   44, 176,   8,   8,  4, -1, 0x0204, "br" },
  {   45, 180,  12,  12,  4, -1, 0x020c, "scompare1" },
  {   46, 184,   0,   0,  4, -1, 0x0210, "acclo" },
  {   47, 188,   4,   4,  4, -1, 0x0211, "acchi" },
  {   48, 192,  16,  16,  4, -1, 0x0220, "m0" },
  {   49, 196,  20,  20,  4, -1, 0x0221, "m1" },
  {   50, 200,  24,  24,  4, -1, 0x0222, "m2" },
  {   51, 204,  28,  28,  4, -1, 0x0223, "m3" },
  {   53, 212,   0,  32,  4,  1, 0x03f0, "ae_ovf_sar" },
  {   54, 216,   4,  36,  4,  1, 0x03f1, "ae_bithead" },
  {   55, 220,   8,  40,  4,  1, 0x03f2, "ae_ts_fts_bu_bp" },
  {   56, 224,  12,  44,  4,  1, 0x03f3, "ae_cw_sd_no" },
  {   57, 228,  16,  48,  4,  1, 0x03f6, "ae_cbegin0" },
  {   58, 232,  20,  52,  4,  1, 0x03f7, "ae_cend0" },
  {   59, 236,  24,  56,  8,  1, 0x1010, "aed0" },
  {   60, 244,  32,  64,  8,  1, 0x1011, "aed1" },
  {   61, 252,  40,  72,  8,  1, 0x1012, "aed2" },
  {   62, 260,  48,  80,  8,  1, 0x1013, "aed3" },
  {   63, 268,  56,  88,  8,  1, 0x1014, "aed4" },
  {   64, 276,  64,  96,  8,  1, 0x1015, "aed5" },
  {   65, 284,  72, 104,  8,  1, 0x1016, "aed6" },
  {   66, 292,  80, 112,  8,  1, 0x1017, "aed7" },
  {   67, 300,  88, 120,  8,  1, 0x1018, "aed8" },
  {   68, 308,  96, 128,  8,  1, 0x1019, "aed9" },
  {   69, 316, 104, 136,  8,  1, 0x101a, "aed10" },
  {   70, 324, 112, 144,  8,  1, 0x101b, "aed11" },
  {   71, 332, 120, 152,  8,  1, 0x101c, "aed12" },
  {   72, 340, 128, 160,  8,  1, 0x101d, "aed13" },
  {   73, 348, 136, 168,  8,  1, 0x101e, "aed14" },
  {   74, 356, 144, 176,  8,  1, 0x101f, "aed15" },
  {   75, 364, 152, 184,  8,  1, 0x1020, "u0" },
  {   76, 372, 160, 192,  8,  1, 0x1021, "u1" },
  {   77, 380, 168, 200,  8,  1, 0x1022, "u2" },
  {   78, 388, 176, 208,  8,  1, 0x1023, "u3" },
  { 0 }
};

