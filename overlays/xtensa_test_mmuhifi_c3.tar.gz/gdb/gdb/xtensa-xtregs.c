/* Table mapping between kernel xtregset and GDB register cache.
   Copyright 2007, 2008 Free Software Foundation, Inc.

   This file is part of GDB.

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	120

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   44, 176,   0,   0,  4, -1, 0x0204, "br" },
  {   45, 180,   4,   4,  4, -1, 0x020c, "scompare1" },
  {   46, 184,  16,  24,  8,  1, 0x0060, "aep0" },
  {   47, 192,  24,  32,  8,  1, 0x0061, "aep1" },
  {   48, 200,  32,  40,  8,  1, 0x0062, "aep2" },
  {   49, 208,  40,  48,  8,  1, 0x0063, "aep3" },
  {   50, 216,  48,  56,  8,  1, 0x0064, "aep4" },
  {   51, 224,  56,  64,  8,  1, 0x0065, "aep5" },
  {   52, 232,  64,  72,  8,  1, 0x0066, "aep6" },
  {   53, 240,  72,  80,  8,  1, 0x0067, "aep7" },
  {   54, 248,  80,  88,  8,  1, 0x0068, "aeq0" },
  {   55, 256,  88,  96,  8,  1, 0x0069, "aeq1" },
  {   56, 264,  96, 104,  8,  1, 0x006a, "aeq2" },
  {   57, 272, 104, 112,  8,  1, 0x006b, "aeq3" },
  {   58, 280,   0,   8,  4,  1, 0x03f0, "ae_ovf_sar" },
  {   59, 284,   4,  12,  4,  1, 0x03f1, "ae_bithead" },
  {   60, 288,   8,  16,  4,  1, 0x03f2, "ae_ts_fts_bu_bp" },
  {   61, 292,  12,  20,  4,  1, 0x03f3, "ae_sd_no" },
  { 0 }
};

