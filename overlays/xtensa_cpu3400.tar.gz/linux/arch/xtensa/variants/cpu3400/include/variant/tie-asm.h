/* 
 * tie-asm.h -- compile-time HAL assembler definitions dependent on CORE & TIE
 *
 *  NOTE:  This header file is not meant to be included directly.
 */

/* This header file contains assembly-language definitions (assembly
   macros, etc.) for this specific Xtensa processor's TIE extensions
   and options.  It is customized to this Xtensa processor configuration.

   Copyright (c) 1999-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */

#ifndef _XTENSA_CORE_TIE_ASM_H
#define _XTENSA_CORE_TIE_ASM_H

/*  Selection parameter values for save-area save/restore macros:  */
/*  Option vs. TIE:  */
#define XTHAL_SAS_TIE	0x0001	/* custom extension or coprocessor */
#define XTHAL_SAS_OPT	0x0002	/* optional (and not a coprocessor) */
/*  Whether used automatically by compiler:  */
#define XTHAL_SAS_NOCC	0x0004	/* not used by compiler w/o special opts/code */
#define XTHAL_SAS_CC	0x0008	/* used by compiler without special opts/code */
/*  ABI handling across function calls:  */
#define XTHAL_SAS_CALR	0x0010	/* caller-saved */
#define XTHAL_SAS_CALE	0x0020	/* callee-saved */
#define XTHAL_SAS_GLOB	0x0040	/* global across function calls (in thread) */
/*  Misc  */
#define XTHAL_SAS_ALL	0xFFFF	/* include all default NCP contents */



/* Macro to save all non-coprocessor (extra) custom TIE and optional state
 * (not including zero-overhead loop registers).
 * Save area ptr (clobbered):  ptr  (4 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_NCP_NUM_ATMPS needed)
 */
	.macro xchal_ncp_store  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start	\continue, \ofs
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	rsr	\at1, SCOMPARE1		// conditional store option
	s32i	\at1, \ptr, .Lxchal_ofs_ + 0
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_CC | XTHAL_SAS_GLOB) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	rur	\at1, THREADPTR		// threadptr option
	s32i	\at1, \ptr, .Lxchal_ofs_ + 0
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.endm	// xchal_ncp_store

/* Macro to save all non-coprocessor (extra) custom TIE and optional state
 * (not including zero-overhead loop registers).
 * Save area ptr (clobbered):  ptr  (4 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_NCP_NUM_ATMPS needed)
 */
	.macro xchal_ncp_load  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start	\continue, \ofs
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	l32i	\at1, \ptr, .Lxchal_ofs_ + 0
	wsr	\at1, SCOMPARE1		// conditional store option
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.ifeq (XTHAL_SAS_OPT | XTHAL_SAS_CC | XTHAL_SAS_GLOB) & ~\select
	xchal_sa_align	\ptr, 0, 1024-4, 4, 4
	l32i	\at1, \ptr, .Lxchal_ofs_ + 0
	wur	\at1, THREADPTR		// threadptr option
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 4
	.endif
	.endm	// xchal_ncp_load



#define XCHAL_NCP_NUM_ATMPS	1



/* Macro to save the state of TIE coprocessor cpu3400copro_state.
 * Save area ptr (clobbered):  ptr  (4 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_CP2_NUM_ATMPS needed)
 */
#define xchal_cp_cpu3400copro_state_store	xchal_cp2_store
/* #define xchal_cp_cpu3400copro_state_store_a2	xchal_cp2_store a2 a3 a4 a5 a6 */
	.macro	xchal_cp2_store  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start \continue, \ofs
	.ifeq (XTHAL_SAS_TIE | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 0, 1, 4
	rur0	\at1		// STAGE1
	s32i	\at1, \ptr, 0
	rur1	\at1		// STAGE2
	s32i	\at1, \ptr, 4
	rur2	\at1		// INPUT_ALIGN_REG
	s32i	\at1, \ptr, 8
	rur3	\at1		// INPUT_ALIGN_REG_POS
	s32i	\at1, \ptr, 12
	rur4	\at1		// DATA_REG
	s32i	\at1, \ptr, 16
	rur5	\at1		// DATA_REG_POS
	s32i	\at1, \ptr, 20
	rur6	\at1		// CRC_REG
	s32i	\at1, \ptr, 24
	rur7	\at1		// POL_REG00
	s32i	\at1, \ptr, 28
	rur8	\at1		// POL_REG01
	s32i	\at1, \ptr, 32
	rur9	\at1		// POL_REG02
	s32i	\at1, \ptr, 36
	rur10	\at1		// POL_REG03
	s32i	\at1, \ptr, 40
	rur11	\at1		// POL_REG04
	s32i	\at1, \ptr, 44
	rur12	\at1		// POL_REG05
	s32i	\at1, \ptr, 48
	rur13	\at1		// POL_REG06
	s32i	\at1, \ptr, 52
	rur14	\at1		// POL_REG07
	s32i	\at1, \ptr, 56
	rur15	\at1		// POL_REG08
	s32i	\at1, \ptr, 60
	rur16	\at1		// POL_REG09
	s32i	\at1, \ptr, 64
	rur17	\at1		// POL_REG10
	s32i	\at1, \ptr, 68
	rur18	\at1		// POL_REG11
	s32i	\at1, \ptr, 72
	rur19	\at1		// POL_REG12
	s32i	\at1, \ptr, 76
	rur20	\at1		// POL_REG13
	s32i	\at1, \ptr, 80
	rur21	\at1		// POL_REG14
	s32i	\at1, \ptr, 84
	rur22	\at1		// POL_REG15
	s32i	\at1, \ptr, 88
	rur23	\at1		// POL_REG16
	s32i	\at1, \ptr, 92
	rur24	\at1		// POL_REG17
	s32i	\at1, \ptr, 96
	rur25	\at1		// POL_REG18
	s32i	\at1, \ptr, 100
	rur26	\at1		// POL_REG19
	s32i	\at1, \ptr, 104
	rur27	\at1		// POL_REG20
	s32i	\at1, \ptr, 108
	rur28	\at1		// POL_REG21
	s32i	\at1, \ptr, 112
	rur29	\at1		// POL_REG22
	s32i	\at1, \ptr, 116
	rur30	\at1		// POL_REG23
	s32i	\at1, \ptr, 120
	rur31	\at1		// POL_REG24
	s32i	\at1, \ptr, 124
	rur32	\at1		// POL_REG25
	s32i	\at1, \ptr, 128
	rur33	\at1		// POL_REG26
	s32i	\at1, \ptr, 132
	rur34	\at1		// POL_REG27
	s32i	\at1, \ptr, 136
	rur35	\at1		// POL_REG28
	s32i	\at1, \ptr, 140
	rur36	\at1		// POL_REG29
	s32i	\at1, \ptr, 144
	rur37	\at1		// POL_REG30
	s32i	\at1, \ptr, 148
	rur38	\at1		// POL_REG31
	s32i	\at1, \ptr, 152
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 156
	.endif
	.endm	// xchal_cp2_store

/* Macro to restore the state of TIE coprocessor cpu3400copro_state.
 * Save area ptr (clobbered):  ptr  (4 byte aligned)
 * Scratch regs  (clobbered):  at1..at4  (only first XCHAL_CP2_NUM_ATMPS needed)
 */
#define xchal_cp_cpu3400copro_state_load	xchal_cp2_load
/* #define xchal_cp_cpu3400copro_state_load_a2	xchal_cp2_load a2 a3 a4 a5 a6 */
	.macro	xchal_cp2_load  ptr at1 at2 at3 at4  continue=0 ofs=-1 select=XTHAL_SAS_ALL
	xchal_sa_start \continue, \ofs
	.ifeq (XTHAL_SAS_TIE | XTHAL_SAS_NOCC | XTHAL_SAS_CALR) & ~\select
	xchal_sa_align	\ptr, 0, 0, 1, 4
	l32i	\at1, \ptr, 0
	wur0	\at1		// STAGE1
	l32i	\at1, \ptr, 4
	wur1	\at1		// STAGE2
	l32i	\at1, \ptr, 8
	wur2	\at1		// INPUT_ALIGN_REG
	l32i	\at1, \ptr, 12
	wur3	\at1		// INPUT_ALIGN_REG_POS
	l32i	\at1, \ptr, 16
	wur4	\at1		// DATA_REG
	l32i	\at1, \ptr, 20
	wur5	\at1		// DATA_REG_POS
	l32i	\at1, \ptr, 24
	wur6	\at1		// CRC_REG
	l32i	\at1, \ptr, 28
	wur7	\at1		// POL_REG00
	l32i	\at1, \ptr, 32
	wur8	\at1		// POL_REG01
	l32i	\at1, \ptr, 36
	wur9	\at1		// POL_REG02
	l32i	\at1, \ptr, 40
	wur10	\at1		// POL_REG03
	l32i	\at1, \ptr, 44
	wur11	\at1		// POL_REG04
	l32i	\at1, \ptr, 48
	wur12	\at1		// POL_REG05
	l32i	\at1, \ptr, 52
	wur13	\at1		// POL_REG06
	l32i	\at1, \ptr, 56
	wur14	\at1		// POL_REG07
	l32i	\at1, \ptr, 60
	wur15	\at1		// POL_REG08
	l32i	\at1, \ptr, 64
	wur16	\at1		// POL_REG09
	l32i	\at1, \ptr, 68
	wur17	\at1		// POL_REG10
	l32i	\at1, \ptr, 72
	wur18	\at1		// POL_REG11
	l32i	\at1, \ptr, 76
	wur19	\at1		// POL_REG12
	l32i	\at1, \ptr, 80
	wur20	\at1		// POL_REG13
	l32i	\at1, \ptr, 84
	wur21	\at1		// POL_REG14
	l32i	\at1, \ptr, 88
	wur22	\at1		// POL_REG15
	l32i	\at1, \ptr, 92
	wur23	\at1		// POL_REG16
	l32i	\at1, \ptr, 96
	wur24	\at1		// POL_REG17
	l32i	\at1, \ptr, 100
	wur25	\at1		// POL_REG18
	l32i	\at1, \ptr, 104
	wur26	\at1		// POL_REG19
	l32i	\at1, \ptr, 108
	wur27	\at1		// POL_REG20
	l32i	\at1, \ptr, 112
	wur28	\at1		// POL_REG21
	l32i	\at1, \ptr, 116
	wur29	\at1		// POL_REG22
	l32i	\at1, \ptr, 120
	wur30	\at1		// POL_REG23
	l32i	\at1, \ptr, 124
	wur31	\at1		// POL_REG24
	l32i	\at1, \ptr, 128
	wur32	\at1		// POL_REG25
	l32i	\at1, \ptr, 132
	wur33	\at1		// POL_REG26
	l32i	\at1, \ptr, 136
	wur34	\at1		// POL_REG27
	l32i	\at1, \ptr, 140
	wur35	\at1		// POL_REG28
	l32i	\at1, \ptr, 144
	wur36	\at1		// POL_REG29
	l32i	\at1, \ptr, 148
	wur37	\at1		// POL_REG30
	l32i	\at1, \ptr, 152
	wur38	\at1		// POL_REG31
	.set	.Lxchal_ofs_, .Lxchal_ofs_ + 156
	.endif
	.endm	// xchal_cp2_load

#define XCHAL_CP2_NUM_ATMPS	1
#define XCHAL_SA_NUM_ATMPS	1

	/*  Empty macros for unconfigured coprocessors:  */
	.macro xchal_cp0_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp0_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp1_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp1_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp3_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp3_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp4_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp4_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp5_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp5_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp6_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp6_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp7_store	p a b c d continue=0 ofs=-1 select=-1 ; .endm
	.macro xchal_cp7_load	p a b c d continue=0 ofs=-1 select=-1 ; .endm

#endif /*_XTENSA_CORE_TIE_ASM_H*/

