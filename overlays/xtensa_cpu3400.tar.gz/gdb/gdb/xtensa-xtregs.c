/* Customized table mapping between kernel xtregset and GDB register cache.

   Copyright (c) 2007-2010 Tensilica Inc.

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   "Software"), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be included
   in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
   IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
   CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
   TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
   SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.  */


typedef struct {
  int   gdb_regnum;
  int   gdb_offset;
  int   ptrace_cp_offset;
  int   ptrace_offset;
  int   size;
  int   coproc;
  int   dbnum;
  char* name
;} xtensa_regtable_t;

#define XTENSA_ELF_XTREG_SIZE	160

const xtensa_regtable_t  xtensa_regmap_table[] = {
  /* gnum,gofs,cpofs,ofs,siz,cp, dbnum,  name */
  {   76, 304,   0,   0,  4, -1, 0x020c, "scompare1" },
  {   78, 312,   0,   4,  4,  2, 0x0300, "stage1" },
  {   79, 316,   4,   8,  4,  2, 0x0301, "stage2" },
  {   80, 320,   8,  12,  4,  2, 0x0302, "input_align_reg" },
  {   81, 324,  12,  16,  4,  2, 0x0303, "input_align_reg_pos" },
  {   82, 328,  16,  20,  4,  2, 0x0304, "data_reg" },
  {   83, 332,  20,  24,  4,  2, 0x0305, "data_reg_pos" },
  {   84, 336,  24,  28,  4,  2, 0x0306, "crc_reg" },
  {   85, 340,  28,  32,  4,  2, 0x0307, "pol_reg00" },
  {   86, 344,  32,  36,  4,  2, 0x0308, "pol_reg01" },
  {   87, 348,  36,  40,  4,  2, 0x0309, "pol_reg02" },
  {   88, 352,  40,  44,  4,  2, 0x030a, "pol_reg03" },
  {   89, 356,  44,  48,  4,  2, 0x030b, "pol_reg04" },
  {   90, 360,  48,  52,  4,  2, 0x030c, "pol_reg05" },
  {   91, 364,  52,  56,  4,  2, 0x030d, "pol_reg06" },
  {   92, 368,  56,  60,  4,  2, 0x030e, "pol_reg07" },
  {   93, 372,  60,  64,  4,  2, 0x030f, "pol_reg08" },
  {   94, 376,  64,  68,  4,  2, 0x0310, "pol_reg09" },
  {   95, 380,  68,  72,  4,  2, 0x0311, "pol_reg10" },
  {   96, 384,  72,  76,  4,  2, 0x0312, "pol_reg11" },
  {   97, 388,  76,  80,  4,  2, 0x0313, "pol_reg12" },
  {   98, 392,  80,  84,  4,  2, 0x0314, "pol_reg13" },
  {   99, 396,  84,  88,  4,  2, 0x0315, "pol_reg14" },
  {  100, 400,  88,  92,  4,  2, 0x0316, "pol_reg15" },
  {  101, 404,  92,  96,  4,  2, 0x0317, "pol_reg16" },
  {  102, 408,  96, 100,  4,  2, 0x0318, "pol_reg17" },
  {  103, 412, 100, 104,  4,  2, 0x0319, "pol_reg18" },
  {  104, 416, 104, 108,  4,  2, 0x031a, "pol_reg19" },
  {  105, 420, 108, 112,  4,  2, 0x031b, "pol_reg20" },
  {  106, 424, 112, 116,  4,  2, 0x031c, "pol_reg21" },
  {  107, 428, 116, 120,  4,  2, 0x031d, "pol_reg22" },
  {  108, 432, 120, 124,  4,  2, 0x031e, "pol_reg23" },
  {  109, 436, 124, 128,  4,  2, 0x031f, "pol_reg24" },
  {  110, 440, 128, 132,  4,  2, 0x0320, "pol_reg25" },
  {  111, 444, 132, 136,  4,  2, 0x0321, "pol_reg26" },
  {  112, 448, 136, 140,  4,  2, 0x0322, "pol_reg27" },
  {  113, 452, 140, 144,  4,  2, 0x0323, "pol_reg28" },
  {  114, 456, 144, 148,  4,  2, 0x0324, "pol_reg29" },
  {  115, 460, 148, 152,  4,  2, 0x0325, "pol_reg30" },
  {  116, 464, 152, 156,  4,  2, 0x0326, "pol_reg31" },
  { 0 }
};

